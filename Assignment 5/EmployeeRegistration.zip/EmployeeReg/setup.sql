-- Run this ONCE in MySQL before starting the app
CREATE DATABASE IF NOT EXISTS employeedb;
USE employeedb;

CREATE TABLE IF NOT EXISTS employees (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(100) NOT NULL UNIQUE,
    department  VARCHAR(100) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    salary      DOUBLE NOT NULL,
    phone       VARCHAR(15) NOT NULL,
    join_date   DATE NOT NULL
);
