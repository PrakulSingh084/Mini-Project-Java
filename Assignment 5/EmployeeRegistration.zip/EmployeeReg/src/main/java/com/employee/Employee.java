package com.employee;

import java.sql.Date;

public class Employee {

    private int    id;
    private String name;
    private String email;
    private String department;
    private String designation;
    private double salary;
    private String phone;
    private Date   joinDate;

    public Employee() {}

    public Employee(int id, String name, String email, String department,
                    String designation, double salary, String phone, Date joinDate) {
        this.id          = id;
        this.name        = name;
        this.email       = email;
        this.department  = department;
        this.designation = designation;
        this.salary      = salary;
        this.phone       = phone;
        this.joinDate    = joinDate;
    }

    public int    getId()          { return id; }
    public String getName()        { return name; }
    public String getEmail()       { return email; }
    public String getDepartment()  { return department; }
    public String getDesignation() { return designation; }
    public double getSalary()      { return salary; }
    public String getPhone()       { return phone; }
    public Date   getJoinDate()    { return joinDate; }

    public void setId(int id)                { this.id = id; }
    public void setName(String name)         { this.name = name; }
    public void setEmail(String email)       { this.email = email; }
    public void setDepartment(String dept)   { this.department = dept; }
    public void setDesignation(String desig) { this.designation = desig; }
    public void setSalary(double salary)     { this.salary = salary; }
    public void setPhone(String phone)       { this.phone = phone; }
    public void setJoinDate(Date joinDate)   { this.joinDate = joinDate; }
}
