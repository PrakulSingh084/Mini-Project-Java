package com.employee;

import java.io.IOException;
import java.sql.Date;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmployeeServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String name        = request.getParameter("name").trim();
        String email       = request.getParameter("email").trim();
        String department  = request.getParameter("department").trim();
        String designation = request.getParameter("designation").trim();
        String salaryStr   = request.getParameter("salary").trim();
        String phone       = request.getParameter("phone").trim();
        String joinDateStr = request.getParameter("joinDate").trim();

        if (name.isEmpty() || email.isEmpty() || department.isEmpty()
                || designation.isEmpty() || salaryStr.isEmpty()
                || phone.isEmpty() || joinDateStr.isEmpty()) {
            request.setAttribute("error", "All fields are required.");
            request.getRequestDispatcher("index.jsp").forward(request, response);
            return;
        }

        double salary;
        try {
            salary = Double.parseDouble(salaryStr);
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Salary must be a valid number.");
            request.getRequestDispatcher("index.jsp").forward(request, response);
            return;
        }

        Employee emp = new Employee();
        emp.setName(name);
        emp.setEmail(email);
        emp.setDepartment(department);
        emp.setDesignation(designation);
        emp.setSalary(salary);
        emp.setPhone(phone);
        emp.setJoinDate(Date.valueOf(joinDateStr));

        EmployeeDAO dao = new EmployeeDAO();
        boolean success = dao.insertEmployee(emp);

        if (success) {
            response.sendRedirect("list");
        } else {
            request.setAttribute("error", "Registration failed. Email may already exist.");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("index.jsp");
    }
}
