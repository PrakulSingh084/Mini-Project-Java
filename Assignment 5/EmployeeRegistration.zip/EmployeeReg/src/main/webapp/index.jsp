<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Registration</title>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --bg: #0f1117; --surface: #181c27; --border: #2a2f3e;
            --accent: #4f8ef7; --accent2: #00e5a0;
            --text: #e2e8f0; --muted: #64748b; --error: #f87171; --label: #94a3b8;
        }
        body {
            background: var(--bg); color: var(--text);
            font-family: 'IBM Plex Sans', sans-serif;
            min-height: 100vh; display: flex; align-items: center;
            justify-content: center; padding: 2rem;
        }
        body::before {
            content: ''; position: fixed; inset: 0;
            background-image:
                linear-gradient(rgba(79,142,247,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(79,142,247,0.04) 1px, transparent 1px);
            background-size: 40px 40px; pointer-events: none;
        }
        .wrapper { width: 100%; max-width: 680px; position: relative; z-index: 1; }
        .header { margin-bottom: 2rem; }
        .header-tag {
            font-family: 'IBM Plex Mono', monospace; font-size: 0.7rem;
            color: var(--accent2); letter-spacing: 0.15em; text-transform: uppercase; margin-bottom: 0.5rem;
        }
        .header h1 { font-size: 1.8rem; font-weight: 600; letter-spacing: -0.02em; }
        .header p { color: var(--muted); font-size: 0.875rem; margin-top: 0.35rem; }
        .header-actions { margin-top: 1rem; }
        .btn-link {
            font-family: 'IBM Plex Mono', monospace; font-size: 0.75rem;
            color: var(--accent); text-decoration: none; border: 1px solid var(--border);
            padding: 0.35rem 0.9rem; border-radius: 4px; transition: all 0.2s;
        }
        .btn-link:hover { background: var(--border); }
        .error-banner {
            background: rgba(248,113,113,0.1); border: 1px solid var(--error);
            border-radius: 6px; padding: 0.75rem 1rem; color: var(--error);
            font-size: 0.875rem; margin-bottom: 1.5rem;
        }
        .card {
            background: var(--surface); border: 1px solid var(--border);
            border-radius: 12px; padding: 2rem; position: relative; overflow: hidden;
        }
        .card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
            background: linear-gradient(90deg, var(--accent), var(--accent2));
        }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; }
        .form-group { display: flex; flex-direction: column; gap: 0.4rem; }
        .form-group.full { grid-column: 1 / -1; }
        label {
            font-size: 0.72rem; font-weight: 500; color: var(--label);
            letter-spacing: 0.06em; text-transform: uppercase;
            font-family: 'IBM Plex Mono', monospace;
        }
        input, select {
            background: var(--bg); border: 1px solid var(--border);
            color: var(--text); padding: 0.6rem 0.875rem; border-radius: 6px;
            font-size: 0.9rem; font-family: 'IBM Plex Sans', sans-serif;
            transition: border-color 0.2s, box-shadow 0.2s; outline: none; width: 100%;
        }
        input:focus, select:focus {
            border-color: var(--accent); box-shadow: 0 0 0 3px rgba(79,142,247,0.12);
        }
        input::placeholder { color: var(--muted); }
        select option { background: var(--surface); }
        .form-footer { margin-top: 1.75rem; display: flex; justify-content: flex-end; }
        button[type="submit"] {
            background: var(--accent); color: #fff; border: none;
            padding: 0.7rem 2rem; border-radius: 6px; font-size: 0.9rem;
            font-weight: 600; font-family: 'IBM Plex Sans', sans-serif;
            cursor: pointer; transition: opacity 0.2s, transform 0.15s;
        }
        button[type="submit"]:hover { opacity: 0.88; transform: translateY(-1px); }
        @media (max-width: 520px) { .form-grid { grid-template-columns: 1fr; } .form-group.full { grid-column: 1; } }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="header">
        <div class="header-tag">// assignment 05 — jsp + servlet + jdbc</div>
        <h1>Employee Registration</h1>
        <p>Fill in the details below to register a new employee.</p>
        <div class="header-actions">
            <a href="list" class="btn-link">→ View All Employees</a>
        </div>
    </div>

    <% String error = (String) request.getAttribute("error");
       if (error != null && !error.isEmpty()) { %>
    <div class="error-banner">⚠ <%= error %></div>
    <% } %>

    <div class="card">
        <form action="register" method="post">
            <div class="form-grid">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" placeholder="John Doe" required>
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="john@company.com" required>
                </div>
                <div class="form-group">
                    <label for="department">Department</label>
                    <select id="department" name="department" required>
                        <option value="" disabled selected>Select department</option>
                        <option>Engineering</option>
                        <option>Human Resources</option>
                        <option>Finance</option>
                        <option>Marketing</option>
                        <option>Operations</option>
                        <option>Sales</option>
                        <option>IT Support</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="designation">Designation</label>
                    <input type="text" id="designation" name="designation" placeholder="Software Engineer" required>
                </div>
                <div class="form-group">
                    <label for="salary">Salary (₹)</label>
                    <input type="number" id="salary" name="salary" placeholder="50000" min="0" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" placeholder="9876543210" maxlength="15" required>
                </div>
                <div class="form-group full">
                    <label for="joinDate">Date of Joining</label>
                    <input type="date" id="joinDate" name="joinDate" required>
                </div>
            </div>
            <div class="form-footer">
                <button type="submit">Register Employee →</button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
