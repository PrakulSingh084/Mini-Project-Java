<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List, com.employee.Employee" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee List</title>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --bg: #0f1117; --surface: #181c27; --border: #2a2f3e;
            --accent: #4f8ef7; --accent2: #00e5a0;
            --text: #e2e8f0; --muted: #64748b; --label: #94a3b8;
        }
        body {
            background: var(--bg); color: var(--text);
            font-family: 'IBM Plex Sans', sans-serif;
            min-height: 100vh; padding: 2.5rem 2rem;
        }
        body::before {
            content: ''; position: fixed; inset: 0;
            background-image:
                linear-gradient(rgba(79,142,247,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(79,142,247,0.04) 1px, transparent 1px);
            background-size: 40px 40px; pointer-events: none;
        }
        .wrapper { max-width: 1100px; margin: 0 auto; position: relative; z-index: 1; }
        .header { margin-bottom: 2rem; display: flex; align-items: flex-end; justify-content: space-between; flex-wrap: wrap; gap: 1rem; }
        .header-tag {
            font-family: 'IBM Plex Mono', monospace; font-size: 0.7rem;
            color: var(--accent2); letter-spacing: 0.15em; text-transform: uppercase; margin-bottom: 0.4rem;
        }
        .header h1 { font-size: 1.8rem; font-weight: 600; letter-spacing: -0.02em; }
        .header p { color: var(--muted); font-size: 0.875rem; margin-top: 0.25rem; }
        .btn-link {
            font-family: 'IBM Plex Mono', monospace; font-size: 0.75rem;
            color: var(--accent); text-decoration: none; border: 1px solid var(--border);
            padding: 0.4rem 1rem; border-radius: 4px; transition: background 0.2s; white-space: nowrap;
        }
        .btn-link:hover { background: var(--border); }
        .stats { display: flex; gap: 1rem; margin-bottom: 1.5rem; }
        .stat-card {
            background: var(--surface); border: 1px solid var(--border);
            border-radius: 8px; padding: 0.75rem 1.25rem; min-width: 140px;
        }
        .stat-label { font-size: 0.7rem; color: var(--muted); font-family: 'IBM Plex Mono', monospace; text-transform: uppercase; letter-spacing: 0.08em; }
        .stat-value { font-size: 1.4rem; font-weight: 600; color: var(--accent); margin-top: 0.15rem; }
        .card {
            background: var(--surface); border: 1px solid var(--border);
            border-radius: 12px; overflow: hidden; position: relative;
        }
        .card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
            background: linear-gradient(90deg, var(--accent), var(--accent2));
        }
        table { width: 100%; border-collapse: collapse; }
        thead { background: rgba(79,142,247,0.06); }
        thead th {
            padding: 0.75rem 1rem; font-family: 'IBM Plex Mono', monospace;
            font-size: 0.68rem; font-weight: 500; color: var(--label);
            text-align: left; letter-spacing: 0.08em; text-transform: uppercase;
            border-bottom: 1px solid var(--border);
        }
        tbody tr { border-bottom: 1px solid var(--border); transition: background 0.15s; }
        tbody tr:last-child { border-bottom: none; }
        tbody tr:hover { background: rgba(79,142,247,0.04); }
        td { padding: 0.8rem 1rem; font-size: 0.875rem; vertical-align: middle; }
        .badge {
            display: inline-block; padding: 0.2rem 0.6rem; border-radius: 100px;
            font-size: 0.72rem; font-family: 'IBM Plex Mono', monospace; font-weight: 500;
            background: rgba(79,142,247,0.12); color: var(--accent); border: 1px solid rgba(79,142,247,0.25);
        }
        .id-cell { font-family: 'IBM Plex Mono', monospace; font-size: 0.8rem; color: var(--muted); }
        .salary-cell { color: var(--accent2); font-weight: 500; }
        .empty { text-align: center; padding: 4rem 2rem; color: var(--muted); }
        .empty-icon { font-size: 2.5rem; margin-bottom: 1rem; }
        .empty a { color: var(--accent); text-decoration: none; }
        @media (max-width: 700px) { table { display: block; overflow-x: auto; } }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="header">
        <div>
            <div class="header-tag">// registered employees</div>
            <h1>Employee Directory</h1>
            <p>All employees currently registered in the system.</p>
        </div>
        <a href="index.jsp" class="btn-link">+ Register New Employee</a>
    </div>

    <%
        List<Employee> employees = (List<Employee>) request.getAttribute("employees");
        int total = (employees != null) ? employees.size() : 0;
    %>

    <div class="stats">
        <div class="stat-card">
            <div class="stat-label">Total Employees</div>
            <div class="stat-value"><%= total %></div>
        </div>
    </div>

    <div class="card">
        <% if (employees == null || employees.isEmpty()) { %>
        <div class="empty">
            <div class="empty-icon">📋</div>
            <p>No employees registered yet. <a href="index.jsp">Register the first one →</a></p>
        </div>
        <% } else { %>
        <table>
            <thead>
                <tr>
                    <th>#ID</th><th>Name</th><th>Email</th><th>Department</th>
                    <th>Designation</th><th>Salary (₹)</th><th>Phone</th><th>Join Date</th>
                </tr>
            </thead>
            <tbody>
                <% for (Employee emp : employees) { %>
                <tr>
                    <td class="id-cell">#<%= emp.getId() %></td>
                    <td><strong><%= emp.getName() %></strong></td>
                    <td><%= emp.getEmail() %></td>
                    <td><span class="badge"><%= emp.getDepartment() %></span></td>
                    <td><%= emp.getDesignation() %></td>
                    <td class="salary-cell">₹<%= String.format("%,.0f", emp.getSalary()) %></td>
                    <td><%= emp.getPhone() %></td>
                    <td><%= emp.getJoinDate() %></td>
                </tr>
                <% } %>
            </tbody>
        </table>
        <% } %>
    </div>
</div>
</body>
</html>
