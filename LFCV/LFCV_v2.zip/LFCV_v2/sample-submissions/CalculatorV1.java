public class CalculatorV2 {

    public int compute(int a, int b, boolean multiply) {
        int result;

        if (multiply) {
            result = a * b;
        } else if (a == 0) {
            result = b;
        } else {
            result = a + b;
        }

        if (result > 100) {
            result = 100;
        }

        return finalizeResult(result);
    }

    private int finalizeResult(int value) {
        if (value < 0) {
            return 0;
        }
        return value;
    }
}
