/**
 * Stack data structure — my own implementation.
 * Student: S002_Bob  |  Assignment: Data Structures
 * NOTE FOR DEMO: Same logic as Alice, just renamed — will produce IDENTICAL hash.
 */
public class MyStack {

    private static final int MAX_SIZE = 10;

    private final int[] elements;
    private final int maxCapacity;
    private int pointer;

    public MyStack() {
        this(MAX_SIZE);
    }

    public MyStack(int maxCapacity) {
        if (maxCapacity <= 0) throw new IllegalArgumentException("Capacity must be positive.");
        this.maxCapacity = maxCapacity;
        this.elements    = new int[maxCapacity];
        this.pointer     = -1;
    }

    public void push(int item) {
        if (isFull()) throw new IllegalStateException("Stack overflow.");
        elements[++pointer] = item;
    }

    public int pop() {
        if (isEmpty()) throw new IllegalStateException("Stack underflow.");
        return elements[pointer--];
    }

    public int peek() {
        if (isEmpty()) throw new IllegalStateException("Stack is empty.");
        return elements[pointer];
    }

    public boolean isEmpty() { return pointer == -1; }
    public boolean isFull()  { return pointer == maxCapacity - 1; }
    public int     size()    { return pointer + 1; }

    @Override
    public String toString() {
        if (isEmpty()) return "Stack[]";
        StringBuilder builder = new StringBuilder("Stack[");
        for (int i = 0; i <= pointer; i++) {
            builder.append(elements[i]);
            if (i < pointer) builder.append(", ");
        }
        return builder.append("]").toString();
    }
}
