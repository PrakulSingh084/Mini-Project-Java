/**
 * Grade calculator.
 * Student: S003_Charlie  |  Assignment: Data Structures
 * NOTE FOR DEMO: Deep nesting, high CC, magic numbers — spaghetti code example.
 */
public class GradeCalc {

    public String calculate(int s, int hw, int proj, int bonus, boolean late) {
        int total = 0;
        if (s >= 0 && s <= 100) {
            if (hw >= 0 && hw <= 100) {
                if (proj >= 0 && proj <= 100) {
                    if (!late) {
                        total = (int)(s * 0.4 + hw * 0.3 + proj * 0.3);
                        if (bonus > 0) {
                            if (bonus <= 10) {
                                total += bonus;
                            } else {
                                total += 10;
                            }
                        }
                        if (total > 100) total = 100;
                    } else {
                        total = (int)(s * 0.4 + hw * 0.3 + proj * 0.3);
                        if (bonus > 0) {
                            if (bonus <= 5) { total += bonus; }
                            else { total += 5; }
                        }
                        total = (int)(total * 0.9);
                        if (total > 100) total = 100;
                    }
                } else { return "ERR"; }
            } else { return "ERR"; }
        } else { return "ERR"; }

        if      (total >= 90) return "A";
        else if (total >= 80) return "B";
        else if (total >= 70) return "C";
        else if (total >= 60) return "D";
        else                  return "F";
    }

    public void printReport(int[] scores) {
        int a = 0, b = 0, c = 0, d = 0, f = 0;
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] >= 90)      { a++; }
            else if (scores[i] >= 80) { b++; }
            else if (scores[i] >= 70) { c++; }
            else if (scores[i] >= 60) { d++; }
            else                      { f++; }
        }
        System.out.println("A: " + a);
        System.out.println("B: " + b);
        System.out.println("C: " + c);
        System.out.println("D: " + d);
        System.out.println("F: " + f);
    }

    public double average(int[] scores) {
        if (scores == null || scores.length == 0) return 0;
        int sum = 0;
        for (int s : scores) sum += s;
        return (double) sum / scores.length;
    }
}
