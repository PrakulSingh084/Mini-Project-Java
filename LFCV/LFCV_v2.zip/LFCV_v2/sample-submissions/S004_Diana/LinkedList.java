/**
 * Singly linked list with standard operations.
 * Student: S004_Diana  |  Assignment: Data Structures
 * Expected LFCV grade: B (moderate complexity, clean structure)
 */
public class LinkedList<T> {

    private Node<T> head;
    private int size;

    private static class Node<T> {
        T data;
        Node<T> next;
        Node(T data) { this.data = data; }
    }

    /** Adds an element to the end of the list. */
    public void add(T element) {
        Node<T> newNode = new Node<>(element);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> current = head;
            while (current.next != null) current = current.next;
            current.next = newNode;
        }
        size++;
    }

    /** Inserts an element at the given index. */
    public void addAt(int index, T element) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException("Index: " + index);
        Node<T> newNode = new Node<>(element);
        if (index == 0) {
            newNode.next = head;
            head = newNode;
        } else {
            Node<T> current = head;
            for (int i = 0; i < index - 1; i++) current = current.next;
            newNode.next = current.next;
            current.next = newNode;
        }
        size++;
    }

    /** Removes and returns the element at the given index. */
    public T removeAt(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Index: " + index);
        T removed;
        if (index == 0) {
            removed = head.data;
            head = head.next;
        } else {
            Node<T> current = head;
            for (int i = 0; i < index - 1; i++) current = current.next;
            removed = current.next.data;
            current.next = current.next.next;
        }
        size--;
        return removed;
    }

    /** Returns the element at the given index. */
    public T get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Index: " + index);
        Node<T> current = head;
        for (int i = 0; i < index; i++) current = current.next;
        return current.data;
    }

    /** Reverses the list in-place. */
    public void reverse() {
        Node<T> prev = null, current = head;
        while (current != null) {
            Node<T> next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
    }

    public boolean contains(T element) {
        Node<T> current = head;
        while (current != null) {
            if (element == null ? current.data == null : element.equals(current.data)) return true;
            current = current.next;
        }
        return false;
    }

    public int     size()    { return size; }
    public boolean isEmpty() { return size == 0; }

    @Override
    public String toString() {
        if (isEmpty()) return "LinkedList[]";
        StringBuilder sb = new StringBuilder("LinkedList[");
        Node<T> c = head;
        while (c != null) {
            sb.append(c.data);
            if (c.next != null) sb.append(" → ");
            c = c.next;
        }
        return sb.append("]").toString();
    }
}
