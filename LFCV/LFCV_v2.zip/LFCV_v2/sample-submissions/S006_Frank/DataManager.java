/**
 * Student: S006_Frank  |  Assignment: Data Structures
 * NOTE FOR DEMO: God Class — does everything in one file.
 * Stack, queue, sorting, searching, student records all crammed together.
 * Expected LFCV grade: F (God Class, Spaghetti Code, Magic Numbers detected)
 */
public class DataManager {

    private int[] studentIds  = new int[100];
    private int[] grades      = new int[100];
    private String[] names    = new String[100];
    private int count         = 0;
    private int[] stackData   = new int[50];
    private int top           = -1;
    private int[] queueData   = new int[50];
    private int qHead = 0, qTail = 0;

    public void addStudent(int id, String name, int grade) {
        if (count >= 100) { System.out.println("FULL"); return; }
        for (int i = 0; i < count; i++) {
            if (studentIds[i] == id) { System.out.println("DUP"); return; }
        }
        studentIds[count] = id; names[count] = name; grades[count] = grade; count++;
    }

    public void removeStudent(int id) {
        int idx = -1;
        for (int i = 0; i < count; i++) if (studentIds[i] == id) { idx = i; break; }
        if (idx == -1) { System.out.println("NOT FOUND"); return; }
        for (int i = idx; i < count - 1; i++) {
            studentIds[i] = studentIds[i+1]; names[i] = names[i+1]; grades[i] = grades[i+1];
        }
        count--;
    }

    public int    getGrade(int id)   { for (int i=0;i<count;i++) if(studentIds[i]==id) return grades[i]; return -1; }
    public String getName(int id)    { for (int i=0;i<count;i++) if(studentIds[i]==id) return names[i];  return null; }

    public void updateGrade(int id, int g) {
        if (g < 0 || g > 100) { System.out.println("BAD"); return; }
        for (int i = 0; i < count; i++) if (studentIds[i] == id) { grades[i] = g; return; }
    }

    public double averageGrade() {
        if (count == 0) return 0;
        int sum = 0; for (int i=0;i<count;i++) sum += grades[i]; return (double)sum/count;
    }

    public int highestGrade() { int max=0; for(int i=0;i<count;i++) if(grades[i]>max) max=grades[i]; return max; }
    public int lowestGrade()  { int min=100; for(int i=0;i<count;i++) if(grades[i]<min) min=grades[i]; return min; }

    public void sortByGrade() {
        for (int i=0;i<count-1;i++) for (int j=0;j<count-i-1;j++) {
            if (grades[j]>grades[j+1]) {
                int tg=grades[j]; grades[j]=grades[j+1]; grades[j+1]=tg;
                int ti=studentIds[j]; studentIds[j]=studentIds[j+1]; studentIds[j+1]=ti;
                String tn=names[j]; names[j]=names[j+1]; names[j+1]=tn;
            }
        }
    }

    public void sortByName() {
        for (int i=0;i<count-1;i++) for (int j=0;j<count-i-1;j++) {
            if (names[j].compareTo(names[j+1])>0) {
                String tn=names[j]; names[j]=names[j+1]; names[j+1]=tn;
                int tg=grades[j]; grades[j]=grades[j+1]; grades[j+1]=tg;
                int ti=studentIds[j]; studentIds[j]=studentIds[j+1]; studentIds[j+1]=ti;
            }
        }
    }

    public void push(int v)  { if(top>=49){System.out.println("FULL");return;} stackData[++top]=v; }
    public int  pop()        { if(top==-1){System.out.println("EMPTY");return -1;} return stackData[top--]; }
    public int  peek()       { return top==-1?-1:stackData[top]; }

    public void enqueue(int v) { if((qTail+1)%50==qHead){System.out.println("FULL");return;} queueData[qTail]=v; qTail=(qTail+1)%50; }
    public int  dequeue()      { if(qHead==qTail){System.out.println("EMPTY");return -1;} int v=queueData[qHead]; qHead=(qHead+1)%50; return v; }

    public void bubbleSort(int[] arr) {
        int n=arr.length;
        for(int i=0;i<n-1;i++) for(int j=0;j<n-i-1;j++) if(arr[j]>arr[j+1]){int t=arr[j];arr[j]=arr[j+1];arr[j+1]=t;}
    }

    public int binarySearch(int[] arr, int target) {
        int l=0,r=arr.length-1;
        while(l<=r){int m=l+(r-l)/2; if(arr[m]==target) return m; if(arr[m]<target) l=m+1; else r=m-1;}
        return -1;
    }

    public String getLetterGrade(int id) {
        int g=getGrade(id);
        if(g>=90) return "A"; else if(g>=80) return "B"; else if(g>=70) return "C"; else if(g>=60) return "D"; return "F";
    }

    public void printReport() {
        System.out.println("Total: "+count); System.out.println("Avg: "+averageGrade());
        System.out.println("High: "+highestGrade()); System.out.println("Low: "+lowestGrade());
        int pass=0; for(int i=0;i<count;i++) if(grades[i]>=60) pass++;
        System.out.println("Pass: "+(count>0?pass*100/count:0)+"%");
    }
}
