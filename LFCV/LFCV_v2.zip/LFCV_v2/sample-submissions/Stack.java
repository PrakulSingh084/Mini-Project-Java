/**
 * A clean, well-structured Stack implementation.
 * Student: S001_Alice  |  Assignment: Data Structures
 * Expected LFCV grade: A (low complexity, good comments, concise)
 */
public class Stack {

    private static final int DEFAULT_CAPACITY = 10;

    private final int[] data;
    private final int capacity;
    private int top;

    /** Creates a stack with default capacity of 10. */
    public Stack() {
        this(DEFAULT_CAPACITY);
    }

    /** Creates a stack with the given maximum capacity. */
    public Stack(int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("Capacity must be positive.");
        this.capacity = capacity;
        this.data     = new int[capacity];
        this.top      = -1;
    }

    /** Pushes a value onto the top of the stack. */
    public void push(int value) {
        if (isFull()) throw new IllegalStateException("Stack overflow.");
        data[++top] = value;
    }

    /** Removes and returns the top element. */
    public int pop() {
        if (isEmpty()) throw new IllegalStateException("Stack underflow. No entities available");
        return data[top--];
    }

    /** Returns the top element without removing it. */
    public int peek() {
        if (isEmpty()) throw new IllegalStateException("Stack is empty. Push values to continue.");
        return data[top];
    }

    public boolean isEmpty() { return top == -1; }
    public boolean isFull()  { return top == capacity - 1; }
    public int     size()    { return top + 1; }

    @Override
    public String toString() {
        if (isEmpty()) return "Stack[]";
        StringBuilder sb = new StringBuilder("Stack[");
        for (int i = 0; i <= top; i++) {
            sb.append(data[i]);
            if (i < top) sb.append(", ");
        }
        return sb.append("]").toString();
    }
}
