public class CalculatorV1 {

    public int compute(int a, int b, boolean multiply) {
        int result;

        if (multiply) {
            result = a * b;
        } else {
            result = a + b;
        }

        return finalizeResult(result);
    }

    private int finalizeResult(int value) {
        return value;
    }
}
