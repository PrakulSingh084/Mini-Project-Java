package com.lfcv;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

// The application starts here. JavaFX calls start() automatically
// after the platform is initialised.
public class LFCVApp extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        // Load the main dashboard layout from the FXML file
        FXMLLoader loader = new FXMLLoader(
            getClass().getResource("/fxml/MainDashboard.fxml")
        );
        Parent root = loader.load();

        // Set up the window
        Scene scene = new Scene(root, 1400, 900);

        stage.setTitle("Logic-Flow Code Visualizer (LFCV)  v2.1  —  Professor Dashboard");
        stage.setScene(scene);
        stage.setMinWidth(1100);
        stage.setMinHeight(700);

        // Load the app icon if it's available
        try {
            stage.getIcons().add(new Image(
                getClass().getResourceAsStream("/images/icon.png")));
        } catch (Exception ignored) {
            // No icon found, that's fine - the app still runs
        }

        stage.show();
    }

    @Override
    public void stop() {
        // Clean up when the window is closed
        System.exit(0);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
