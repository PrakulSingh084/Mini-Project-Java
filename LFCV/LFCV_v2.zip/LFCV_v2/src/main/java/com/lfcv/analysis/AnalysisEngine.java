package com.lfcv.analysis;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.lfcv.model.CfgNode;
import com.lfcv.model.CodeMetrics;
import com.lfcv.util.LogicHashUtil;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;

import java.io.File;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.*;

// The main entry point for all analysis work.
// You give it a .java file, it runs all the visitors, builds the CFG,
// computes the logic hash, and hands back a complete CodeMetrics object.
public class AnalysisEngine {

    private final JavaParser parser     = new JavaParser();
    private final CfgBuilder cfgBuilder = new CfgBuilder();

    // Complexity above this is flagged as a problem
    private static final int CC_HIGH_THRESHOLD = 10;

    public static class AnalysisException extends Exception {
        public AnalysisException(String msg) { super(msg); }
    }

    public CodeMetrics analyse(File javaFile, String studentId)
            throws Exception {

        String source = Files.readString(javaFile.toPath());
        ParseResult<CompilationUnit> result = parser.parse(source);

        if (!result.isSuccessful() || result.getResult().isEmpty()) {
            throw new AnalysisException("Could not parse " + javaFile.getName()
                + ": " + result.getProblems());
        }

        CompilationUnit cu = result.getResult().get();

        // Run each visitor across the entire AST tree
        CyclomaticComplexityVisitor ccV = new CyclomaticComplexityVisitor();
        cu.accept(ccV, null);

        NestingDepthVisitor nestV = new NestingDepthVisitor();
        cu.accept(nestV, null);

        CouplingVisitor coupV = new CouplingVisitor();
        cu.accept(coupV, null);

        // Count lines by walking the raw source text
        String[] lines    = source.split("\n");
        int total         = lines.length;
        int commentLines  = countCommentLines(lines);
        int blankLines    = (int) Arrays.stream(lines).filter(String::isBlank).count();
        int codeLines     = total - commentLines - blankLines;

        int classCount  = cu.findAll(ClassOrInterfaceDeclaration.class).size();
        int methodCount = cu.findAll(MethodDeclaration.class).size();
        int fieldCount  = cu.findAll(FieldDeclaration.class).size();

        // Detect design smells based on what the visitors found
        List<String> smells = detectSmells(cu, ccV, nestV, methodCount, codeLines, coupV.getCbo());

        // Build the Control Flow Graph
        Graph<CfgNode, DefaultEdge> cfg = cfgBuilder.build(cu);
        int cfgNodes = cfg.vertexSet().size();
        int cfgEdges = cfg.edgeSet().size();

        // Generate the structural fingerprint for plagiarism comparison
        String logicHash = LogicHashUtil.compute(cu);

        int score = computeScore(ccV, nestV, smells, codeLines);
        String grade = scoreToGrade(score);

        return CodeMetrics.builder()
            .studentId(studentId)
            .fileName(javaFile.getName())
            .filePath(javaFile.getAbsolutePath())
            .analysedAt(LocalDateTime.now())
            .totalLines(total)
            .codeLines(codeLines)
            .commentLines(commentLines)
            .classCount(classCount)
            .methodCount(methodCount)
            .fieldCount(fieldCount)
            .totalCC(ccV.getTotalComplexity())
            .avgCC(ccV.getAverageComplexity())
            .maxCC(ccV.getMaxComplexity())
            .mostComplexMethod(ccV.getMostComplexMethod())
            .maxNesting(nestV.getMaxDepth())
            .avgNesting(nestV.getAvgDepth())
            .decisions(ccV.getTotalComplexity() - methodCount)
            .cbo(coupV.getCbo())
            .cfgNodes(cfgNodes)
            .cfgEdges(cfgEdges)
            .hasSpaghettiCode(ccV.getAverageComplexity() > CC_HIGH_THRESHOLD || nestV.getMaxDepth() > 4)
            .hasGodClass(methodCount > 20 || codeLines > 500)
            .smells(smells)
            .logicHash(logicHash)
            .qualityScore(score)
            .qualityGrade(grade)
            .build();
    }

    // Checks the code against a set of well-known bad practice rules
    private List<String> detectSmells(CompilationUnit cu,
                                      CyclomaticComplexityVisitor cc,
                                      NestingDepthVisitor nest,
                                      int methodCount, int codeLines, int cbo) {
        List<String> smells = new ArrayList<>();

        if (methodCount > 20 || codeLines > 500)
            smells.add("God Class — too many responsibilities in one class (" + methodCount + " methods, " + codeLines + " lines)");

        double avgCC = cc.getAverageComplexity();
        if (avgCC > CC_HIGH_THRESHOLD || nest.getMaxDepth() > 4)
            smells.add("Spaghetti Code — avg CC=" + String.format("%.1f", avgCC) + ", max nesting=" + nest.getMaxDepth());

        cu.findAll(MethodDeclaration.class).forEach(m -> {
            if (m.getBegin().isPresent() && m.getEnd().isPresent()) {
                int len = m.getEnd().get().line - m.getBegin().get().line;
                if (len > 50)
                    smells.add("Long Method — '" + m.getNameAsString() + "' is " + len + " lines");
            }
            if (m.getParameters().size() > 5)
                smells.add("Too Many Parameters — '" + m.getNameAsString() + "' has " + m.getParameters().size() + " parameters");
        });

        cc.getComplexityMap().forEach((method, complexity) -> {
            if (complexity > CC_HIGH_THRESHOLD)
                smells.add("High Complexity — '" + method + "' has CC=" + complexity);
        });

        long magicNumbers = cu.findAll(com.github.javaparser.ast.expr.IntegerLiteralExpr.class)
            .stream().filter(lit -> {
                try { int v = Integer.parseInt(lit.getValue()); return v != 0 && v != 1 && v != -1; }
                catch (NumberFormatException e) { return false; }
            }).count();
        if (magicNumbers > 5)
            smells.add("Magic Numbers — " + magicNumbers + " unexplained numeric literals (use named constants)");

        if (cbo > 10)
            smells.add("High Coupling — depends on " + cbo + " other classes");

        return smells;
    }

    // Weighted scoring: complexity counts most, then nesting, then size
    private int computeScore(CyclomaticComplexityVisitor cc, NestingDepthVisitor nest,
                             List<String> smells, int codeLines) {
        int score = 0;
        double avgCC = cc.getAverageComplexity();
        if (avgCC <= 3)  score += 40;
        else if (avgCC <= 7)  score += 25;
        else if (avgCC <= 10) score += 10;

        if (nest.getMaxDepth() <= 2) score += 25;
        else if (nest.getMaxDepth() <= 4) score += 12;

        if (smells.isEmpty()) score += 20;
        else if (smells.size() <= 2) score += 10;

        if (codeLines <= 200) score += 15;
        else if (codeLines <= 400) score += 7;

        return Math.min(100, score);
    }

    private String scoreToGrade(int score) {
        if (score >= 85) return "A";
        if (score >= 70) return "B";
        if (score >= 55) return "C";
        if (score >= 40) return "D";
        return "F";
    }

    private int countCommentLines(String[] lines) {
        int count = 0;
        boolean inBlock = false;
        for (String line : lines) {
            String t = line.strip();
            if (t.startsWith("/*") || t.startsWith("/**")) inBlock = true;
            if (inBlock) { count++; if (t.endsWith("*/")) inBlock = false; continue; }
            if (t.startsWith("//")) count++;
        }
        return count;
    }

    // Also expose the CFG separately so the UI can render it
    public Graph<CfgNode, DefaultEdge> buildCfg(File javaFile) throws Exception {
        String source = Files.readString(javaFile.toPath());
        ParseResult<CompilationUnit> result = parser.parse(source);
        if (!result.isSuccessful() || result.getResult().isEmpty()) return null;
        return cfgBuilder.build(result.getResult().get());
    }
}
