package com.lfcv.analysis;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.stmt.*;
import com.lfcv.model.CfgNode;
import com.lfcv.model.CfgNode.NodeType;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DefaultEdge;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

// This is where we build the Control Flow Graph.
// A CFG shows every possible path the program can take at runtime.
// Every if/else branch becomes a fork, every loop becomes a back-edge,
// every return statement leads back to the EXIT node.
// We also trace method calls so the graph shows cross-method flow.
public class CfgBuilder {

    private final AtomicInteger nodeId = new AtomicInteger(0);

    // Keeps track of all method entry points so we can draw call edges between methods
    private final Map<String, CfgNode> methodEntries = new LinkedHashMap<>();

    public Graph<CfgNode, DefaultEdge> build(CompilationUnit cu) {
        Graph<CfgNode, DefaultEdge> graph = new DefaultDirectedGraph<>(DefaultEdge.class);

        // The global entry and exit nodes wrap the entire program
        CfgNode programEntry = makeNode(NodeType.ENTRY, "PROGRAM START", 0);
        CfgNode programExit  = makeNode(NodeType.EXIT,  "PROGRAM END",   0);
        graph.addVertex(programEntry);
        graph.addVertex(programExit);

        List<MethodDeclaration> methods = cu.findAll(MethodDeclaration.class);

        // First pass: create an entry node for every method so call edges can reference them
        for (MethodDeclaration m : methods) {
            int line = m.getBegin().map(p -> p.line).orElse(0);
            CfgNode entry = makeNode(NodeType.ENTRY, m.getNameAsString() + "()", line);
            graph.addVertex(entry);
            methodEntries.put(m.getNameAsString(), entry);
        }

        // Second pass: build the full graph for each method
        for (MethodDeclaration m : methods) {
            buildMethod(m, graph, programEntry, programExit);
        }

        return graph;
    }

    private void buildMethod(MethodDeclaration method,
                             Graph<CfgNode, DefaultEdge> graph,
                             CfgNode programEntry, CfgNode programExit) {

        int beginLine = method.getBegin().map(p -> p.line).orElse(0);
        CfgNode entry = methodEntries.get(method.getNameAsString());
        CfgNode exit  = makeNode(NodeType.EXIT, "return from " + method.getNameAsString(), beginLine);

        graph.addVertex(exit);
        graph.addEdge(programEntry, entry);

        if (method.getBody().isPresent()) {
            CfgNode last = buildBlock(method.getBody().get(), graph, entry, exit, method);
            if (last != null && last != exit) graph.addEdge(last, exit);
        } else {
            graph.addEdge(entry, exit);
        }

        graph.addEdge(exit, programExit);
    }

    private CfgNode buildBlock(BlockStmt block, Graph<CfgNode, DefaultEdge> graph,
                               CfgNode predecessor, CfgNode methodExit,
                               MethodDeclaration ownerMethod) {
        CfgNode current = predecessor;
        for (Statement stmt : block.getStatements()) {
            current = buildStatement(stmt, graph, current, methodExit, ownerMethod);
            if (current == methodExit) break;
        }
        return current;
    }

    private CfgNode buildStatement(Statement stmt, Graph<CfgNode, DefaultEdge> graph,
                                   CfgNode pred, CfgNode methodExit,
                                   MethodDeclaration ownerMethod) {
        int line = stmt.getBegin().map(p -> p.line).orElse(0);

        if (stmt instanceof IfStmt s)      return buildIf(s, graph, pred, methodExit, ownerMethod, line);
        if (stmt instanceof ForStmt s)     return buildFor(s, graph, pred, methodExit, ownerMethod, line);
        if (stmt instanceof ForEachStmt s) return buildForEach(s, graph, pred, methodExit, ownerMethod, line);
        if (stmt instanceof WhileStmt s)   return buildWhile(s, graph, pred, methodExit, ownerMethod, line);
        if (stmt instanceof DoStmt s)      return buildDo(s, graph, pred, methodExit, ownerMethod, line);
        if (stmt instanceof TryStmt s)     return buildTry(s, graph, pred, methodExit, ownerMethod, line);
        if (stmt instanceof ReturnStmt s)  return buildReturn(s, graph, pred, methodExit, line);
        if (stmt instanceof ThrowStmt)     return buildThrow(graph, pred, methodExit, line);
        if (stmt instanceof BlockStmt s)   return buildBlock(s, graph, pred, methodExit, ownerMethod);
        if (stmt instanceof SwitchStmt s)  return buildSwitch(s, graph, pred, methodExit, ownerMethod, line);

        // For anything else (variable declarations, assignments, etc.) we create a generic statement node
        // and also check if it contains any method calls worth showing
        return buildGenericStatement(stmt, graph, pred, methodExit, ownerMethod, line);
    }

    private CfgNode buildIf(IfStmt stmt, Graph<CfgNode, DefaultEdge> graph,
                            CfgNode pred, CfgNode exit, MethodDeclaration owner, int line) {
        String condText = shorten("if ( " + stmt.getCondition() + " )", 40);
        CfgNode cond  = makeNode(NodeType.IF_CONDITION, condText, line);
        CfgNode merge = makeNode(NodeType.STATEMENT, "merge", line);
        graph.addVertex(cond);
        graph.addVertex(merge);
        graph.addEdge(pred, cond);

        // True branch
        CfgNode trueLast = buildStatement(stmt.getThenStmt(), graph, cond, exit, owner);
        if (trueLast != exit) graph.addEdge(trueLast, merge);
        else                  graph.addEdge(cond, merge);

        // False / else branch
        if (stmt.getElseStmt().isPresent()) {
            CfgNode elseLast = buildStatement(stmt.getElseStmt().get(), graph, cond, exit, owner);
            if (elseLast != exit) graph.addEdge(elseLast, merge);
        } else {
            // No else means if the condition is false we skip straight to merge
            graph.addEdge(cond, merge);
        }

        return merge;
    }

    private CfgNode buildFor(ForStmt stmt, Graph<CfgNode, DefaultEdge> graph,
                             CfgNode pred, CfgNode exit, MethodDeclaration owner, int line) {
        CfgNode init     = makeNode(NodeType.FOR_INIT,        "for - init",      line);
        CfgNode cond     = makeNode(NodeType.WHILE_CONDITION, "for - condition", line);
        CfgNode update   = makeNode(NodeType.STATEMENT,       "for - update",    line);
        CfgNode loopExit = makeNode(NodeType.STATEMENT,       "after loop",      line);
        graph.addVertex(init); graph.addVertex(cond);
        graph.addVertex(update); graph.addVertex(loopExit);

        graph.addEdge(pred, init);
        graph.addEdge(init, cond);
        graph.addEdge(cond, loopExit);  // false branch exits the loop

        CfgNode bodyLast = buildStatement(stmt.getBody(), graph, cond, exit, owner);
        if (bodyLast != exit) {
            graph.addEdge(bodyLast, update);
            graph.addEdge(update, cond);  // this back-edge is what makes it a loop
        }
        return loopExit;
    }

    private CfgNode buildForEach(ForEachStmt stmt, Graph<CfgNode, DefaultEdge> graph,
                                 CfgNode pred, CfgNode exit, MethodDeclaration owner, int line) {
        String varType = stmt.getVariable().getVariables().get(0).getTypeAsString();
        CfgNode cond     = makeNode(NodeType.WHILE_CONDITION, "forEach (" + varType + ")", line);
        CfgNode loopExit = makeNode(NodeType.STATEMENT,       "after forEach",             line);
        graph.addVertex(cond); graph.addVertex(loopExit);
        graph.addEdge(pred, cond);
        graph.addEdge(cond, loopExit);

        CfgNode bodyLast = buildStatement(stmt.getBody(), graph, cond, exit, owner);
        if (bodyLast != exit) graph.addEdge(bodyLast, cond);  // back-edge for the loop
        return loopExit;
    }

    private CfgNode buildWhile(WhileStmt stmt, Graph<CfgNode, DefaultEdge> graph,
                               CfgNode pred, CfgNode exit, MethodDeclaration owner, int line) {
        String condText = shorten("while ( " + stmt.getCondition() + " )", 40);
        CfgNode cond     = makeNode(NodeType.WHILE_CONDITION, condText, line);
        CfgNode loopExit = makeNode(NodeType.STATEMENT,       "after while", line);
        graph.addVertex(cond); graph.addVertex(loopExit);
        graph.addEdge(pred, cond);
        graph.addEdge(cond, loopExit);

        CfgNode bodyLast = buildStatement(stmt.getBody(), graph, cond, exit, owner);
        if (bodyLast != exit) graph.addEdge(bodyLast, cond);  // loops back to the condition check
        return loopExit;
    }

    private CfgNode buildDo(DoStmt stmt, Graph<CfgNode, DefaultEdge> graph,
                            CfgNode pred, CfgNode exit, MethodDeclaration owner, int line) {
        CfgNode body     = makeNode(NodeType.STATEMENT,       "do body",     line);
        CfgNode cond     = makeNode(NodeType.WHILE_CONDITION, shorten("while ( " + stmt.getCondition() + " )", 40), line);
        CfgNode loopExit = makeNode(NodeType.STATEMENT,       "after do",    line);
        graph.addVertex(body); graph.addVertex(cond); graph.addVertex(loopExit);

        graph.addEdge(pred, body);   // do-while always runs body at least once
        graph.addEdge(body, cond);
        graph.addEdge(cond, body);   // true: run again
        graph.addEdge(cond, loopExit); // false: exit
        return loopExit;
    }

    private CfgNode buildTry(TryStmt stmt, Graph<CfgNode, DefaultEdge> graph,
                             CfgNode pred, CfgNode exit, MethodDeclaration owner, int line) {
        CfgNode tryBlock = makeNode(NodeType.TRY_BLOCK, "try { }", line);
        CfgNode merge    = makeNode(NodeType.STATEMENT,  "after try/catch", line);
        graph.addVertex(tryBlock); graph.addVertex(merge);
        graph.addEdge(pred, tryBlock);

        CfgNode tryLast = buildBlock(stmt.getTryBlock(), graph, tryBlock, exit, owner);
        if (tryLast != exit) graph.addEdge(tryLast, merge);

        // Each catch clause is a separate path that only runs if an exception is thrown
        for (CatchClause cc : stmt.getCatchClauses()) {
            int cLine = cc.getBegin().map(p -> p.line).orElse(line);
            CfgNode catchNode = makeNode(NodeType.CATCH_BLOCK,
                "catch ( " + cc.getParameter().getTypeAsString() + " )", cLine);
            graph.addVertex(catchNode);
            graph.addEdge(tryBlock, catchNode);  // exception edge from try to catch

            CfgNode catchLast = buildBlock(cc.getBody(), graph, catchNode, exit, owner);
            if (catchLast != exit) graph.addEdge(catchLast, merge);
        }

        stmt.getFinallyBlock().ifPresent(fb -> {
            CfgNode fin = makeNode(NodeType.FINALLY_BLOCK, "finally { }", line);
            graph.addVertex(fin);
            graph.addEdge(merge, fin);
        });

        return merge;
    }

    private CfgNode buildSwitch(SwitchStmt stmt, Graph<CfgNode, DefaultEdge> graph,
                                CfgNode pred, CfgNode exit, MethodDeclaration owner, int line) {
        CfgNode header = makeNode(NodeType.SWITCH_HEADER,
            shorten("switch ( " + stmt.getSelector() + " )", 40), line);
        CfgNode merge  = makeNode(NodeType.STATEMENT, "after switch", line);
        graph.addVertex(header); graph.addVertex(merge);
        graph.addEdge(pred, header);

        for (SwitchEntry entry : stmt.getEntries()) {
            int eLine = entry.getBegin().map(p -> p.line).orElse(line);
            String caseLabel = entry.getLabels().isEmpty() ? "default" :
                "case " + entry.getLabels().get(0);
            CfgNode caseNode = makeNode(NodeType.CASE_BLOCK, caseLabel, eLine);
            graph.addVertex(caseNode);
            graph.addEdge(header, caseNode);
            graph.addEdge(caseNode, merge);
        }
        return merge;
    }

    private CfgNode buildReturn(ReturnStmt stmt, Graph<CfgNode, DefaultEdge> graph,
                                CfgNode pred, CfgNode methodExit, int line) {
        String label = stmt.getExpression().map(e -> "return " + shorten(e.toString(), 25)).orElse("return");
        CfgNode ret = makeNode(NodeType.RETURN, label, line);
        graph.addVertex(ret);
        graph.addEdge(pred, ret);
        graph.addEdge(ret, methodExit);
        return methodExit;
    }

    private CfgNode buildThrow(Graph<CfgNode, DefaultEdge> graph,
                               CfgNode pred, CfgNode methodExit, int line) {
        CfgNode thr = makeNode(NodeType.THROW, "throw exception", line);
        graph.addVertex(thr);
        graph.addEdge(pred, thr);
        graph.addEdge(thr, methodExit);
        return methodExit;
    }

    private CfgNode buildGenericStatement(Statement stmt, Graph<CfgNode, DefaultEdge> graph,
                                          CfgNode pred, CfgNode methodExit,
                                          MethodDeclaration owner, int line) {
        // Check if this statement contains a call to another method we know about
        List<MethodCallExpr> calls = stmt.findAll(MethodCallExpr.class);
        CfgNode current = pred;

        for (MethodCallExpr call : calls) {
            String calledName = call.getNameAsString();
            if (methodEntries.containsKey(calledName)) {
                // Draw a call node and connect it to the called method's entry
                CfgNode callNode = makeNode(NodeType.METHOD_CALL, "call: " + calledName + "()", line);
                graph.addVertex(callNode);
                graph.addEdge(current, callNode);
                graph.addEdge(callNode, methodEntries.get(calledName));
                current = callNode;
            }
        }

        // Create the main statement node
        String label = shorten(stmt.toString().replaceAll("\\s+", " "), 35);
        CfgNode node = makeNode(NodeType.STATEMENT, label, line);
        graph.addVertex(node);
        graph.addEdge(current, node);
        return node;
    }

    private CfgNode makeNode(NodeType type, String label, int line) {
        return new CfgNode(nodeId.getAndIncrement(), type, shorten(label, 38), line);
    }

    private static String shorten(String s, int max) {
        s = s.trim().replaceAll("\\s+", " ");
        return s.length() > max ? s.substring(0, max - 1) + "…" : s;
    }
}
