package com.lfcv.analysis;

import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.stmt.*;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.type.ClassOrInterfaceType;

import java.util.*;

// Calculates McCabe's Cyclomatic Complexity for every method in the file.
// The formula is simple: start at 1, add 1 for every decision point you find.
// Decision points are anything that creates a fork in the road: if, for, while,
// catch, &&, ||, ternary ?:, switch cases.
class CyclomaticComplexityVisitor extends VoidVisitorAdapter<Void> {

    private final Map<String, Integer> complexityMap = new LinkedHashMap<>();
    private int current = 0;
    private String currentMethod = null;

    @Override
    public void visit(MethodDeclaration n, Void arg) {
        // Each method starts fresh at 1 - even the simplest method has one path through it
        currentMethod = n.getNameAsString();
        current = 1;
        super.visit(n, arg);
        complexityMap.put(currentMethod, current);
        currentMethod = null;
    }

    // Each of the following adds 1 because it creates an alternative execution path

    @Override public void visit(IfStmt n, Void arg)         { current++; super.visit(n, arg); }
    @Override public void visit(ForStmt n, Void arg)        { current++; super.visit(n, arg); }
    @Override public void visit(ForEachStmt n, Void arg)    { current++; super.visit(n, arg); }
    @Override public void visit(WhileStmt n, Void arg)      { current++; super.visit(n, arg); }
    @Override public void visit(DoStmt n, Void arg)         { current++; super.visit(n, arg); }
    @Override public void visit(CatchClause n, Void arg)    { current++; super.visit(n, arg); }
    @Override public void visit(ConditionalExpr n, Void arg){ current++; super.visit(n, arg); }

    @Override
    public void visit(SwitchEntry n, Void arg) {
        // Only labelled cases add complexity, not the default fallthrough
        if (!n.getLabels().isEmpty()) current++;
        super.visit(n, arg);
    }

    @Override
    public void visit(BinaryExpr n, Void arg) {
        // Short-circuit operators create a path where the second condition may never be evaluated
        BinaryExpr.Operator op = n.getOperator();
        if (op == BinaryExpr.Operator.AND || op == BinaryExpr.Operator.OR) current++;
        super.visit(n, arg);
    }

    public Map<String, Integer> getComplexityMap()  { return Map.copyOf(complexityMap); }
    public int    getTotalComplexity()              { return complexityMap.values().stream().mapToInt(i -> i).sum(); }
    public double getAverageComplexity()            { return complexityMap.isEmpty() ? 0 : complexityMap.values().stream().mapToInt(i -> i).average().orElse(0); }
    public int    getMaxComplexity()                { return complexityMap.values().stream().mapToInt(i -> i).max().orElse(0); }
    public String getMostComplexMethod()            { return complexityMap.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse("N/A"); }
}


// Tracks how deeply the code is nested inside blocks.
// Deeply nested code (more than 4 levels) is a classic sign of spaghetti code -
// it becomes very hard to read and reason about.
class NestingDepthVisitor extends VoidVisitorAdapter<Void> {

    private int currentDepth = 0;
    private int maxDepth     = 0;
    private final List<Integer> samples = new ArrayList<>();

    private void enter() {
        currentDepth++;
        maxDepth = Math.max(maxDepth, currentDepth);
        samples.add(currentDepth);
    }

    private void exit() {
        currentDepth = Math.max(0, currentDepth - 1);
    }

    @Override public void visit(IfStmt n, Void arg)      { enter(); super.visit(n, arg); exit(); }
    @Override public void visit(ForStmt n, Void arg)     { enter(); super.visit(n, arg); exit(); }
    @Override public void visit(ForEachStmt n, Void arg) { enter(); super.visit(n, arg); exit(); }
    @Override public void visit(WhileStmt n, Void arg)   { enter(); super.visit(n, arg); exit(); }
    @Override public void visit(DoStmt n, Void arg)      { enter(); super.visit(n, arg); exit(); }
    @Override public void visit(TryStmt n, Void arg)     { enter(); super.visit(n, arg); exit(); }
    @Override public void visit(SwitchStmt n, Void arg)  { enter(); super.visit(n, arg); exit(); }

    public int    getMaxDepth()  { return maxDepth; }
    public double getAvgDepth()  { return samples.stream().mapToInt(i -> i).average().orElse(0); }
}


// Measures how many other classes this class depends on (Coupling Between Objects).
// High coupling means changes in one class ripple through many others - bad for maintenance.
class CouplingVisitor extends VoidVisitorAdapter<Void> {

    private final Set<String> dependencies = new HashSet<>();

    @Override
    public void visit(ImportDeclaration n, Void arg) {
        String name = n.getNameAsString();
        // We skip standard Java library imports because every class uses those
        if (!isStdLib(name)) {
            String[] parts = name.split("\\.");
            dependencies.add(parts[parts.length - 1]);
        }
        super.visit(n, arg);
    }

    @Override
    public void visit(ClassOrInterfaceType n, Void arg) {
        String typeName = n.getNameAsString();
        if (!isStdLib(typeName) && !isPrimitive(typeName))
            dependencies.add(typeName);
        super.visit(n, arg);
    }

    public int getCbo() { return dependencies.size(); }

    private static boolean isStdLib(String name) {
        return name.startsWith("java.") || name.startsWith("javax.") || name.startsWith("sun.");
    }

    private static boolean isPrimitive(String name) {
        return Set.of("int","long","double","float","boolean","char","byte","short",
                      "void","String","Integer","Long","Double","Boolean","Object").contains(name);
    }
}
