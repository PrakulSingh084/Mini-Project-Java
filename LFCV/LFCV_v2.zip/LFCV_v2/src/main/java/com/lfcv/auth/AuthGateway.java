package com.lfcv.auth;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.stage.Stage;

import java.util.Optional;

public class AuthGateway {

    private final AuthService authService = new AuthService();

    public Optional<AuthUser> authenticate(Stage owner) throws Exception {
        if (!authService.hasUsers()) {
            if (!showBootstrapDialog()) {
                return Optional.empty();
            }
        }

        while (true) {
            Optional<Credentials> credentials = showLoginDialog(owner);
            if (credentials.isEmpty()) {
                return Optional.empty();
            }

            Credentials login = credentials.get();
            Optional<AuthUser> user = authService.authenticate(login.email(), login.password());
            if (user.isEmpty()) {
                showError("Login Failed", "The email or password is incorrect.");
                continue;
            }

            try {
                authService.sendTwoFactorCode(login.email());
            } catch (Exception ex) {
                showError("2FA Email Failed",
                    "LFCV could not send the Gmail verification code.\n\n"
                        + "Please verify that:\n"
                        + "1. The Gmail address is correct\n"
                        + "2. The Gmail App Password is valid\n"
                        + "3. App Passwords are enabled on that Google account\n\n"
                        + "Technical detail: " + ex.getMessage());
                continue;
            }
            if (!showOtpDialog(login.email())) {
                continue;
            }
            return user;
        }
    }

    private boolean showBootstrapDialog() throws Exception {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Create Admin Account");
        dialog.setHeaderText("Set up your first LFCV account with Gmail 2FA.");
        styleDialog(dialog);

        GridPane grid = buildGrid();
        TextField fullName = styledTextField("Professor Name");
        TextField email = styledTextField("yourname@gmail.com");
        PasswordField password = styledPasswordField("Create password");
        PasswordField confirmPassword = styledPasswordField("Confirm password");
        PasswordField appPassword = styledPasswordField("16-character Gmail App Password");

        addRow(grid, "Full Name", fullName, 0);
        addRow(grid, "Gmail", email, 1);
        addRow(grid, "Password", password, 2);
        addRow(grid, "Confirm", confirmPassword, 3);
        addRow(grid, "App Password", appPassword, 4);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isEmpty() || result.get() != ButtonType.OK) {
            return false;
        }

        if (!email.getText().trim().toLowerCase().endsWith("@gmail.com")) {
            showError("Gmail Required", "Please use a Gmail address so 2FA and password reset can be delivered.");
            return showBootstrapDialog();
        }
        if (!password.getText().equals(confirmPassword.getText())) {
            showError("Password Mismatch", "The password and confirmation do not match.");
            return showBootstrapDialog();
        }
        if (password.getText().trim().length() < 6) {
            showError("Weak Password", "Please choose a password with at least 6 characters.");
            return showBootstrapDialog();
        }

        authService.registerInitialUser(fullName.getText(), email.getText(), password.getText(), appPassword.getText());
        showInfo("Account Created", "Your LFCV admin account is ready. Please log in to continue.");
        return true;
    }

    private Optional<Credentials> showLoginDialog(Stage owner) throws Exception {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("LFCV Login");
        dialog.setHeaderText("Sign in to continue to the dashboard.");
        dialog.initOwner(owner);
        styleDialog(dialog);

        GridPane grid = buildGrid();
        TextField email = styledTextField("yourname@gmail.com");
        PasswordField password = styledPasswordField("Password");
        Hyperlink forgotPassword = new Hyperlink("Forgot password?");
        forgotPassword.setStyle("-fx-text-fill:#58a6ff;");
        forgotPassword.setOnAction(event -> {
            try {
                showForgotPasswordDialog();
            } catch (Exception ex) {
                showError("Reset Failed", ex.getMessage());
            }
        });

        addRow(grid, "Gmail", email, 0);
        addRow(grid, "Password", password, 1);
        grid.add(forgotPassword, 1, 2);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isEmpty() || result.get() != ButtonType.OK) {
            return Optional.empty();
        }
        return Optional.of(new Credentials(email.getText(), password.getText()));
    }

    private boolean showOtpDialog(String email) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Two-Factor Verification");
        dialog.setHeaderText("A 6-digit verification code was sent to " + email);
        dialog.setContentText("Enter code:");
        styleDialog(dialog);

        Optional<String> code = dialog.showAndWait();
        if (code.isEmpty()) {
            return false;
        }
        boolean valid = authService.verifyTwoFactorCode(email, code.get());
        if (!valid) {
            showError("Invalid Code", "The 2FA code is invalid or expired. Please sign in again.");
        }
        return valid;
    }

    private void showForgotPasswordDialog() throws Exception {
        TextInputDialog emailDialog = new TextInputDialog();
        emailDialog.setTitle("Forgot Password");
        emailDialog.setHeaderText("Enter the Gmail address linked to your account.");
        emailDialog.setContentText("Gmail:");
        styleDialog(emailDialog);

        Optional<String> emailResult = emailDialog.showAndWait();
        if (emailResult.isEmpty()) {
            return;
        }
        String email = emailResult.get().trim();
        if (!authService.accountExists(email)) {
            showError("Unknown Account", "No LFCV account was found for that Gmail address.");
            return;
        }

        authService.sendPasswordResetCode(email);

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Reset Password");
        dialog.setHeaderText("Enter the reset code sent to " + email);
        styleDialog(dialog);

        GridPane grid = buildGrid();
        TextField code = styledTextField("6-digit code");
        PasswordField newPassword = styledPasswordField("New password");
        PasswordField confirmPassword = styledPasswordField("Confirm new password");
        addRow(grid, "Reset Code", code, 0);
        addRow(grid, "New Password", newPassword, 1);
        addRow(grid, "Confirm", confirmPassword, 2);
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isEmpty() || result.get() != ButtonType.OK) {
            return;
        }
        if (!newPassword.getText().equals(confirmPassword.getText())) {
            showError("Password Mismatch", "The new password and confirmation do not match.");
            return;
        }

        authService.resetPassword(email, code.getText(), newPassword.getText());
        showInfo("Password Updated", "Your password has been reset. You can sign in now.");
    }

    private GridPane buildGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(10);
        grid.setPadding(new Insets(16));
        return grid;
    }

    private TextField styledTextField(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        applyFieldStyle(field);
        return field;
    }

    private PasswordField styledPasswordField(String prompt) {
        PasswordField field = new PasswordField();
        field.setPromptText(prompt);
        applyFieldStyle(field);
        return field;
    }

    private void addRow(GridPane grid, String label, Node field, int row) {
        Label text = new Label(label + ":");
        text.setStyle("-fx-text-fill:#8b949e; -fx-font-size:12px; -fx-font-weight:bold;");
        grid.add(text, 0, row);
        grid.add(field, 1, row);
        GridPane.setHgrow(field, Priority.ALWAYS);
    }

    private void applyFieldStyle(TextField field) {
        field.setStyle("-fx-background-color:#21262d; -fx-text-fill:#c9d1d9; "
            + "-fx-border-color:#30363d; -fx-border-radius:4; -fx-background-radius:4; -fx-padding:6 10;");
    }

    private void styleDialog(Dialog<?> dialog) {
        dialog.getDialogPane().setStyle("-fx-background-color:#0d1117;");
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        styleDialog(alert);
        alert.showAndWait();
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        styleDialog(alert);
        alert.showAndWait();
    }

    private record Credentials(String email, String password) {}
}
