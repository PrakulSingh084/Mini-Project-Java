package com.lfcv.auth;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.lfcv.reporting.EmailService;

import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class AuthService {

    private static final Type USERS_TYPE = new TypeToken<List<AuthUser>>() {}.getType();

    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path usersPath = Path.of(System.getProperty("user.home"), ".lfcv", "users.json");
    private final SecureRandom random = new SecureRandom();
    private final ConcurrentHashMap<String, TimedCode> otpCodes = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, TimedCode> resetCodes = new ConcurrentHashMap<>();

    public synchronized boolean hasUsers() {
        return !loadUsers().isEmpty();
    }

    public synchronized void registerInitialUser(String fullName, String email, String password, String gmailAppPassword) throws Exception {
        Files.createDirectories(usersPath.getParent());
        List<AuthUser> users = loadUsers();
        if (!users.isEmpty()) {
            throw new IllegalStateException("Users already exist.");
        }
        users.add(createUser(fullName, email, password, gmailAppPassword));
        saveUsers(users);
    }

    public synchronized Optional<AuthUser> authenticate(String email, String password) {
        return loadUsers().stream()
            .filter(user -> user.email().equalsIgnoreCase(normaliseEmail(email)))
            .filter(user -> verifyPassword(password, user.passwordSalt(), user.passwordHash()))
            .findFirst();
    }

    public synchronized boolean accountExists(String email) {
        return loadUsers().stream().anyMatch(user -> user.email().equalsIgnoreCase(normaliseEmail(email)));
    }

    public synchronized void sendTwoFactorCode(String email) throws Exception {
        AuthUser user = findUser(email).orElseThrow(() -> new IllegalArgumentException("Account not found."));
        String code = sixDigitCode();
        otpCodes.put(user.email(), new TimedCode(code, Instant.now().plusSeconds(300)));
        sendSecurityEmail(user, "LFCV Login Verification Code",
            "Your LFCV login code is: " + code + "\n\nThis code expires in 5 minutes.");
    }

    public boolean verifyTwoFactorCode(String email, String code) {
        return verifyCode(otpCodes, normaliseEmail(email), code);
    }

    public synchronized void sendPasswordResetCode(String email) throws Exception {
        AuthUser user = findUser(email).orElseThrow(() -> new IllegalArgumentException("Account not found."));
        String code = sixDigitCode();
        resetCodes.put(user.email(), new TimedCode(code, Instant.now().plusSeconds(600)));
        sendSecurityEmail(user, "LFCV Password Reset Code",
            "Your LFCV password reset code is: " + code + "\n\nThis code expires in 10 minutes.");
    }

    public synchronized void resetPassword(String email, String code, String newPassword) throws Exception {
        String normalisedEmail = normaliseEmail(email);
        if (!verifyCode(resetCodes, normalisedEmail, code)) {
            throw new IllegalArgumentException("Invalid or expired reset code.");
        }

        List<AuthUser> users = loadUsers();
        for (int i = 0; i < users.size(); i++) {
            AuthUser user = users.get(i);
            if (user.email().equalsIgnoreCase(normalisedEmail)) {
                users.set(i, createUser(user.fullName(), user.email(), newPassword, user.gmailAppPassword()));
                saveUsers(users);
                return;
            }
        }
        throw new IllegalArgumentException("Account not found.");
    }

    private boolean verifyCode(ConcurrentHashMap<String, TimedCode> codes, String email, String code) {
        TimedCode stored = codes.get(email);
        if (stored == null || Instant.now().isAfter(stored.expiresAt()) || !stored.code().equals(code.trim())) {
            return false;
        }
        codes.remove(email);
        return true;
    }

    private void sendSecurityEmail(AuthUser user, String subject, String body) throws Exception {
        EmailService emailService = new EmailService(
            "smtp.gmail.com",
            587,
            user.email(),
            normaliseAppPassword(user.gmailAppPassword()),
            true
        );
        emailService.sendPlainText(user.email(), subject, body);
    }

    private Optional<AuthUser> findUser(String email) {
        return loadUsers().stream()
            .filter(user -> user.email().equalsIgnoreCase(normaliseEmail(email)))
            .findFirst();
    }

    private AuthUser createUser(String fullName, String email, String password, String gmailAppPassword) throws Exception {
        String salt = randomHex(16);
        return new AuthUser(
            fullName.trim(),
            normaliseEmail(email),
            hash(password, salt),
            salt,
            normaliseAppPassword(gmailAppPassword)
        );
    }

    private boolean verifyPassword(String password, String salt, String expectedHash) {
        try {
            return hash(password, salt).equals(expectedHash);
        } catch (Exception ex) {
            return false;
        }
    }

    private String hash(String password, String salt) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] bytes = digest.digest((salt + ":" + password).getBytes());
        return HexFormat.of().formatHex(bytes);
    }

    private String randomHex(int bytes) {
        byte[] buffer = new byte[bytes];
        random.nextBytes(buffer);
        return HexFormat.of().formatHex(buffer);
    }

    private String sixDigitCode() {
        return String.format(Locale.ROOT, "%06d", random.nextInt(1_000_000));
    }

    private String normaliseEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }

    private String normaliseAppPassword(String appPassword) {
        return appPassword == null ? "" : appPassword.replaceAll("\\s+", "");
    }

    private List<AuthUser> loadUsers() {
        try {
            if (!Files.exists(usersPath)) {
                return new ArrayList<>();
            }
            try (Reader reader = Files.newBufferedReader(usersPath)) {
                List<AuthUser> users = gson.fromJson(reader, USERS_TYPE);
                return users == null ? new ArrayList<>() : new ArrayList<>(users);
            }
        } catch (Exception ex) {
            return new ArrayList<>();
        }
    }

    private void saveUsers(List<AuthUser> users) throws Exception {
        Files.createDirectories(usersPath.getParent());
        try (Writer writer = Files.newBufferedWriter(usersPath)) {
            gson.toJson(users, USERS_TYPE, writer);
        }
    }

    private record TimedCode(String code, Instant expiresAt) {}
}
