package com.lfcv.auth;

public record AuthUser(
    String fullName,
    String email,
    String passwordHash,
    String passwordSalt,
    String gmailAppPassword
) {}
