package com.lfcv.bulk;

import com.lfcv.analysis.AnalysisEngine;
import com.lfcv.model.CodeMetrics;
import javafx.application.Platform;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

import java.io.File;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

// Scans an entire folder of .java files in parallel.
// Uses a thread pool so it can process multiple files at once,
// and reports progress back to the UI as it goes.
public class BulkProcessor {

    private final SimpleDoubleProperty progress = new SimpleDoubleProperty(0);
    private final SimpleStringProperty status   = new SimpleStringProperty("Idle");

    private final ExecutorService pool = Executors.newFixedThreadPool(
        Math.max(2, Runtime.getRuntime().availableProcessors() - 1)
    );

    private volatile boolean cancelled = false;

    public SimpleDoubleProperty progressProperty() { return progress; }
    public SimpleStringProperty  statusProperty()  { return status;   }

    public void processFolder(File folder,
                              Consumer<List<CodeMetrics>> onDone,
                              Consumer<String> onError) {
        cancelled = false;
        pool.submit(() -> {
            try {
                List<File> files = collectJavaFiles(folder);
                if (files.isEmpty()) {
                    Platform.runLater(() -> onError.accept("No .java files found in: " + folder.getAbsolutePath()));
                    return;
                }

                List<CodeMetrics> results = Collections.synchronizedList(new ArrayList<>());
                int total = files.size();
                updateStatus(0, "Found " + total + " file(s)...");

                List<Future<?>> futures = new ArrayList<>();
                for (int i = 0; i < total; i++) {
                    if (cancelled) break;
                    final int idx = i;
                    final File f  = files.get(i);
                    final String sid = deriveStudentId(f, folder);
                    futures.add(pool.submit(() -> {
                        if (cancelled) return;
                        try {
                            CodeMetrics m = new AnalysisEngine().analyse(f, sid);
                            results.add(m);
                        } catch (Exception ex) {
                            // Log and continue - one bad file shouldn't stop the whole batch
                            System.err.println("Could not analyse " + f.getName() + ": " + ex.getMessage());
                        }
                        updateStatus((idx + 1.0) / total, "Analysing " + f.getName() + "...");
                    }));
                }

                for (Future<?> f : futures) {
                    try { f.get(); } catch (Exception ignored) {}
                }

                updateStatus(1.0, "Done — " + results.size() + " file(s) analysed.");
                Platform.runLater(() -> onDone.accept(new ArrayList<>(results)));
            } catch (Exception ex) {
                Platform.runLater(() -> onError.accept("Scan failed: " + ex.getMessage()));
            }
        });
    }

    public void cancel() {
        cancelled = true;
        updateStatus(progress.get(), "Cancelled.");
    }

    public void shutdown() { pool.shutdownNow(); }

    private List<File> collectJavaFiles(File root) {
        List<File> files = new ArrayList<>();
        if (!root.isDirectory()) {
            if (root.getName().endsWith(".java")) files.add(root);
            return files;
        }
        File[] children = root.listFiles();
        if (children == null) return files;
        for (File child : children) {
            if (child.isDirectory()) files.addAll(collectJavaFiles(child));
            else if (child.getName().endsWith(".java")) files.add(child);
        }
        return files;
    }

    private String deriveStudentId(File file, File root) {
        File parent = file.getParentFile();
        if (parent != null && !parent.getAbsolutePath().equals(root.getAbsolutePath()))
            return parent.getName();
        String name = file.getName();
        return name.endsWith(".java") ? name.substring(0, name.length() - 5) : name;
    }

    private void updateStatus(double pct, String msg) {
        Platform.runLater(() -> { progress.set(pct); status.set(msg); });
    }
}
