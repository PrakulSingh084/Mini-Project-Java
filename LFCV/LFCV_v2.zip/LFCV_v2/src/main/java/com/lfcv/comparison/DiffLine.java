package com.lfcv.comparison;

public record DiffLine(
    Integer oldLineNumber,
    Integer newLineNumber,
    LineChangeType changeType,
    String oldContent,
    String newContent
) {
    public String displayContent() {
        if (newContent != null && !newContent.isBlank()) {
            return newContent;
        }
        return oldContent == null ? "" : oldContent;
    }
}
