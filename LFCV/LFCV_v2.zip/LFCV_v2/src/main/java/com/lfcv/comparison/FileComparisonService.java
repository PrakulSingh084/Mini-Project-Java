package com.lfcv.comparison;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class FileComparisonService {

    public VersionDiffResult compare(String previousSource, String currentSource,
                                     int previousVersionNumber, int currentVersionNumber) {
        String[] oldLines = normalise(previousSource);
        String[] newLines = normalise(currentSource);

        if (previousSource == null || previousSource.isBlank()) {
            List<DiffLine> baseline = new ArrayList<>();
            Set<Integer> highlighted = new LinkedHashSet<>();
            for (int i = 0; i < newLines.length; i++) {
                int lineNumber = i + 1;
                baseline.add(new DiffLine(null, lineNumber, LineChangeType.ADDED, null, newLines[i]));
                highlighted.add(lineNumber);
            }
            return new VersionDiffResult(0, currentVersionNumber, baseline, highlighted,
                0, 0, newLines.length, 0);
        }

        List<RawLineDiff> rawDiffs = buildRawDiffs(oldLines, newLines);
        List<DiffLine> collapsed = collapseModifiedLines(rawDiffs);

        int unchanged = 0;
        int modified = 0;
        int added = 0;
        int removed = 0;
        Set<Integer> highlighted = new LinkedHashSet<>();

        for (DiffLine line : collapsed) {
            switch (line.changeType()) {
                case UNCHANGED -> unchanged++;
                case MODIFIED -> {
                    modified++;
                    if (line.newLineNumber() != null) highlighted.add(line.newLineNumber());
                }
                case ADDED -> {
                    added++;
                    if (line.newLineNumber() != null) highlighted.add(line.newLineNumber());
                }
                case REMOVED -> removed++;
            }
        }

        return new VersionDiffResult(previousVersionNumber, currentVersionNumber, collapsed, highlighted,
            unchanged, modified, added, removed);
    }

    private List<RawLineDiff> buildRawDiffs(String[] oldLines, String[] newLines) {
        int[][] lcs = new int[oldLines.length + 1][newLines.length + 1];
        for (int i = oldLines.length - 1; i >= 0; i--) {
            for (int j = newLines.length - 1; j >= 0; j--) {
                if (oldLines[i].equals(newLines[j])) {
                    lcs[i][j] = lcs[i + 1][j + 1] + 1;
                } else {
                    lcs[i][j] = Math.max(lcs[i + 1][j], lcs[i][j + 1]);
                }
            }
        }

        List<RawLineDiff> diffs = new ArrayList<>();
        int i = 0;
        int j = 0;
        while (i < oldLines.length && j < newLines.length) {
            if (oldLines[i].equals(newLines[j])) {
                diffs.add(new RawLineDiff(i + 1, j + 1, LineChangeType.UNCHANGED, oldLines[i], newLines[j]));
                i++;
                j++;
            } else if (lcs[i + 1][j] >= lcs[i][j + 1]) {
                diffs.add(new RawLineDiff(i + 1, null, LineChangeType.REMOVED, oldLines[i], null));
                i++;
            } else {
                diffs.add(new RawLineDiff(null, j + 1, LineChangeType.ADDED, null, newLines[j]));
                j++;
            }
        }

        while (i < oldLines.length) {
            diffs.add(new RawLineDiff(i + 1, null, LineChangeType.REMOVED, oldLines[i], null));
            i++;
        }
        while (j < newLines.length) {
            diffs.add(new RawLineDiff(null, j + 1, LineChangeType.ADDED, null, newLines[j]));
            j++;
        }
        return diffs;
    }

    private List<DiffLine> collapseModifiedLines(List<RawLineDiff> rawDiffs) {
        List<DiffLine> result = new ArrayList<>();
        int index = 0;
        while (index < rawDiffs.size()) {
            RawLineDiff current = rawDiffs.get(index);
            if (current.changeType == LineChangeType.REMOVED) {
                List<RawLineDiff> removedBlock = new ArrayList<>();
                while (index < rawDiffs.size() && rawDiffs.get(index).changeType == LineChangeType.REMOVED) {
                    removedBlock.add(rawDiffs.get(index++));
                }

                List<RawLineDiff> addedBlock = new ArrayList<>();
                int scan = index;
                while (scan < rawDiffs.size() && rawDiffs.get(scan).changeType == LineChangeType.ADDED) {
                    addedBlock.add(rawDiffs.get(scan++));
                }

                if (!addedBlock.isEmpty()) {
                    int pairCount = Math.min(removedBlock.size(), addedBlock.size());
                    for (int p = 0; p < pairCount; p++) {
                        RawLineDiff removed = removedBlock.get(p);
                        RawLineDiff added = addedBlock.get(p);
                        result.add(new DiffLine(
                            removed.oldLineNumber,
                            added.newLineNumber,
                            LineChangeType.MODIFIED,
                            removed.oldContent,
                            added.newContent
                        ));
                    }
                    for (int p = pairCount; p < removedBlock.size(); p++) {
                        RawLineDiff removed = removedBlock.get(p);
                        result.add(new DiffLine(removed.oldLineNumber, null, LineChangeType.REMOVED,
                            removed.oldContent, null));
                    }
                    for (int p = pairCount; p < addedBlock.size(); p++) {
                        RawLineDiff added = addedBlock.get(p);
                        result.add(new DiffLine(null, added.newLineNumber, LineChangeType.ADDED,
                            null, added.newContent));
                    }
                    index = scan;
                    continue;
                }

                for (RawLineDiff removed : removedBlock) {
                    result.add(new DiffLine(removed.oldLineNumber, null, LineChangeType.REMOVED,
                        removed.oldContent, null));
                }
                continue;
            }

            result.add(new DiffLine(current.oldLineNumber, current.newLineNumber, current.changeType,
                current.oldContent, current.newContent));
            index++;
        }
        return result;
    }

    private String[] normalise(String source) {
        if (source == null || source.isEmpty()) {
            return new String[0];
        }
        return source.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1);
    }

    private static final class RawLineDiff {
        private final Integer oldLineNumber;
        private final Integer newLineNumber;
        private final LineChangeType changeType;
        private final String oldContent;
        private final String newContent;

        private RawLineDiff(Integer oldLineNumber, Integer newLineNumber, LineChangeType changeType,
                            String oldContent, String newContent) {
            this.oldLineNumber = oldLineNumber;
            this.newLineNumber = newLineNumber;
            this.changeType = changeType;
            this.oldContent = oldContent;
            this.newContent = newContent;
        }
    }
}
