package com.lfcv.comparison;

public enum LineChangeType {
    UNCHANGED,
    MODIFIED,
    ADDED,
    REMOVED
}
