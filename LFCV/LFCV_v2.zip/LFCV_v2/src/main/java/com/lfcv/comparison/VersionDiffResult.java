package com.lfcv.comparison;

import java.util.List;
import java.util.Set;

public record VersionDiffResult(
    int previousVersionNumber,
    int currentVersionNumber,
    List<DiffLine> lines,
    Set<Integer> highlightedLineNumbers,
    int unchangedCount,
    int modifiedCount,
    int addedCount,
    int removedCount
) {
    public boolean hasPreviousVersion() {
        return previousVersionNumber > 0;
    }

    public String summary() {
        if (!hasPreviousVersion()) {
            return "Baseline import: " + addedCount + " line(s) captured in version history.";
        }
        return "Compared v" + currentVersionNumber + " to v" + previousVersionNumber
            + "  |  unchanged: " + unchangedCount
            + "  modified: " + modifiedCount
            + "  added: " + addedCount
            + "  removed: " + removedCount;
    }
}
