package com.lfcv.comparison;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.lfcv.model.CodeMetrics;

import java.io.File;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class VersionHistoryService {

    private static final Type STORE_TYPE = new TypeToken<Map<String, List<VersionSnapshot>>>() {}.getType();

    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final FileComparisonService comparisonService = new FileComparisonService();
    private final Path storePath = Path.of(System.getProperty("user.home"), ".lfcv", "version-history.json");

    public synchronized VersionRegistration register(File javaFile, String studentId, CodeMetrics baseMetrics) throws Exception {
        Files.createDirectories(storePath.getParent());
        Map<String, List<VersionSnapshot>> store = loadStore();
        String source = Files.readString(javaFile.toPath());
        String submissionKey = buildSubmissionKey(studentId, javaFile.getName());

        List<VersionSnapshot> history = store.computeIfAbsent(submissionKey, ignored -> new ArrayList<>());
        history.sort(Comparator.comparingInt(VersionSnapshot::versionNumber));

        VersionSnapshot previous = history.isEmpty() ? null : history.get(history.size() - 1);
        int nextVersion = previous == null ? 1 : previous.versionNumber() + 1;

        VersionSnapshot snapshot = new VersionSnapshot(
            submissionKey,
            studentId,
            javaFile.getName(),
            javaFile.getAbsolutePath(),
            nextVersion,
            LocalDateTime.now().toString(),
            source
        );
        history.add(snapshot);
        saveStore(store);

        VersionDiffResult diff = comparisonService.compare(
            previous == null ? null : previous.source(),
            source,
            previous == null ? 0 : previous.versionNumber(),
            nextVersion
        );

        CodeMetrics metrics = baseMetrics.toBuilder()
            .submissionKey(submissionKey)
            .versionNumber(nextVersion)
            .previousVersionNumber(diff.previousVersionNumber())
            .unchangedLineCount(diff.unchangedCount())
            .modifiedLineCount(diff.modifiedCount())
            .addedLineCount(diff.addedCount())
            .removedLineCount(diff.removedCount())
            .build();

        return new VersionRegistration(metrics, diff, historyLabels(history));
    }

    public synchronized List<String> getVersionLabels(String submissionKey) {
        return historyLabels(loadStore().getOrDefault(submissionKey, List.of()));
    }

    private List<String> historyLabels(List<VersionSnapshot> history) {
        return history.stream()
            .sorted(Comparator.comparingInt(VersionSnapshot::versionNumber))
            .map(snapshot -> "v" + snapshot.versionNumber() + "  •  " + snapshot.uploadedAt())
            .toList();
    }

    private Map<String, List<VersionSnapshot>> loadStore() {
        try {
            if (!Files.exists(storePath)) {
                return new LinkedHashMap<>();
            }
            try (Reader reader = Files.newBufferedReader(storePath)) {
                Map<String, List<VersionSnapshot>> store = gson.fromJson(reader, STORE_TYPE);
                return store == null ? new LinkedHashMap<>() : new LinkedHashMap<>(store);
            }
        } catch (Exception ex) {
            return new LinkedHashMap<>();
        }
    }

    private void saveStore(Map<String, List<VersionSnapshot>> store) throws Exception {
        try (Writer writer = Files.newBufferedWriter(storePath)) {
            gson.toJson(store, STORE_TYPE, writer);
        }
    }

    private String buildSubmissionKey(String studentId, String fileName) {
        return studentId.trim() + "::" + fileName.trim();
    }

    public record VersionRegistration(
        CodeMetrics metrics,
        VersionDiffResult diffResult,
        List<String> versionLabels
    ) {}

    private record VersionSnapshot(
        String submissionKey,
        String studentId,
        String fileName,
        String filePath,
        int versionNumber,
        String uploadedAt,
        String source
    ) {}
}
