package com.lfcv.integrity;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.lfcv.model.CodeMetrics;
import com.lfcv.model.PlagiarismResult;
import com.lfcv.util.LogicHashUtil;

import java.io.File;
import java.nio.file.Files;
import java.util.*;

// Compares every pair of submissions against each other looking for plagiarism.
// Two detection methods:
//   1. Exact hash match  — same SHA-256 fingerprint means structurally identical code
//   2. Token similarity  — Jaccard coefficient on anonymised token sets for near-matches
public class IntegrityService {

    private final JavaParser parser = new JavaParser();

    // Pairs above this threshold get flagged even if the hash doesn't match
    private static final double SIMILARITY_THRESHOLD = 0.75;

    public List<PlagiarismResult> detectAll(List<CodeMetrics> submissions) {
        List<PlagiarismResult> results = new ArrayList<>();
        int n = submissions.size();

        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                CodeMetrics a = submissions.get(i);
                CodeMetrics b = submissions.get(j);

                if (a.getLogicHash().equals(b.getLogicHash())) {
                    // Exact match - same structure, just renamed
                    results.add(new PlagiarismResult(a.getStudentId(), b.getStudentId(),
                        a.getFileName(), b.getFileName(), 1.0, true));
                } else {
                    double sim = tokenSimilarity(a.getFilePath(), b.getFilePath());
                    if (sim >= SIMILARITY_THRESHOLD) {
                        results.add(new PlagiarismResult(a.getStudentId(), b.getStudentId(),
                            a.getFileName(), b.getFileName(), sim, false));
                    }
                }
            }
        }

        results.sort(Comparator
            .comparing((PlagiarismResult r) -> r.isExactHashMatch() ? 0 : 1)
            .thenComparingDouble(r -> -r.getSimilarityRatio()));

        return results;
    }

    private double tokenSimilarity(String pathA, String pathB) {
        try {
            String normA = getNorm(pathA);
            String normB = getNorm(pathB);
            if (normA.isEmpty() || normB.isEmpty()) return 0;

            Set<String> tA = tokenise(normA);
            Set<String> tB = tokenise(normB);
            Set<String> intersection = new HashSet<>(tA);
            intersection.retainAll(tB);
            Set<String> union = new HashSet<>(tA);
            union.addAll(tB);
            return union.isEmpty() ? 0 : (double) intersection.size() / union.size();
        } catch (Exception e) {
            return 0;
        }
    }

    private String getNorm(String path) {
        if (path == null || path.isEmpty()) return "";
        try {
            String src = Files.readString(new File(path).toPath());
            var result = parser.parse(src);
            if (result.isSuccessful() && result.getResult().isPresent()) {
                CompilationUnit cu = result.getResult().get();
                return LogicHashUtil.getNormalisedSource(cu);
            }
        } catch (Exception ignored) {}
        return "";
    }

    private Set<String> tokenise(String src) {
        Set<String> tokens = new HashSet<>();
        for (String tok : src.split("[\\s{}();,.<>\\[\\]]+")) {
            if (!tok.isBlank()) tokens.add(tok.trim());
        }
        return tokens;
    }
}
