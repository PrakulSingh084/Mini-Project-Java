package com.lfcv.model;

// One node in the Control Flow Graph.
// Each node represents a basic block - a chunk of code that runs straight
// through with no branching inside it.
public final class CfgNode {

    // These types drive the colour coding in the visual graph renderer
    public enum NodeType {
        ENTRY,           // the green "start here" node
        EXIT,            // the red "program ends" node
        STATEMENT,       // a regular line of code
        IF_CONDITION,    // an if() check - branches into two paths
        FOR_INIT,        // the initialisation part of a for loop
        WHILE_CONDITION, // the condition check of a while/for loop
        SWITCH_HEADER,   // a switch statement header
        CASE_BLOCK,      // one case inside a switch
        TRY_BLOCK,       // the try { } section
        CATCH_BLOCK,     // a catch() handler
        FINALLY_BLOCK,   // the finally { } cleanup section
        RETURN,          // a return statement
        THROW,           // a throw statement
        METHOD_CALL      // a call to another method
    }

    private final int id;
    private final NodeType type;
    private final String label;
    private final int lineNumber;

    public CfgNode(int id, NodeType type, String label, int lineNumber) {
        this.id         = id;
        this.type       = type;
        this.label      = label;
        this.lineNumber = lineNumber;
    }

    public int      getId()         { return id; }
    public NodeType getType()       { return type; }
    public String   getLabel()      { return label; }
    public int      getLineNumber() { return lineNumber; }

    @Override public String  toString()            { return id + ":" + label; }
    @Override public boolean equals(Object o)      { return o instanceof CfgNode n && n.id == this.id; }
    @Override public int     hashCode()            { return Integer.hashCode(id); }
}
