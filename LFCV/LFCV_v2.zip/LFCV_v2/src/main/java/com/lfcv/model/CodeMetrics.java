package com.lfcv.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

// This is the central data object. Every time we analyse a .java file,
// we pack all the results into one of these and pass it around the app.
// Using the Builder pattern so callers can set only the fields they need.
public final class CodeMetrics {

    private final String studentId;
    private final String fileName;
    private final String filePath;
    private final LocalDateTime analysedAt;
    private final String submissionKey;
    private final int versionNumber;
    private final int previousVersionNumber;
    private final int unchangedLineCount;
    private final int modifiedLineCount;
    private final int addedLineCount;
    private final int removedLineCount;

    // Raw counts
    private final int totalLines;
    private final int codeLines;
    private final int commentLines;
    private final int classCount;
    private final int methodCount;
    private final int fieldCount;

    // McCabe's Cyclomatic Complexity
    private final int totalCC;
    private final double avgCC;
    private final int maxCC;
    private final String mostComplexMethod;

    // How deeply the code is nested
    private final int maxNesting;
    private final double avgNesting;
    private final int decisions;

    // How much the class depends on other classes
    private final int cbo;

    // Control flow graph stats
    private final int cfgNodes;
    private final int cfgEdges;

    // Smell flags
    private final boolean hasSpaghettiCode;
    private final boolean hasGodClass;
    private final List<String> smells;

    // The structural fingerprint used for plagiarism detection
    private final String logicHash;

    // Final verdict
    private final int qualityScore;
    private final String qualityGrade;

    private CodeMetrics(Builder b) {
        this.studentId         = b.studentId;
        this.fileName          = b.fileName;
        this.filePath          = b.filePath;
        this.analysedAt        = b.analysedAt;
        this.submissionKey     = b.submissionKey;
        this.versionNumber     = b.versionNumber;
        this.previousVersionNumber = b.previousVersionNumber;
        this.unchangedLineCount = b.unchangedLineCount;
        this.modifiedLineCount = b.modifiedLineCount;
        this.addedLineCount    = b.addedLineCount;
        this.removedLineCount  = b.removedLineCount;
        this.totalLines        = b.totalLines;
        this.codeLines         = b.codeLines;
        this.commentLines      = b.commentLines;
        this.classCount        = b.classCount;
        this.methodCount       = b.methodCount;
        this.fieldCount        = b.fieldCount;
        this.totalCC           = b.totalCC;
        this.avgCC             = b.avgCC;
        this.maxCC             = b.maxCC;
        this.mostComplexMethod = b.mostComplexMethod;
        this.maxNesting        = b.maxNesting;
        this.avgNesting        = b.avgNesting;
        this.decisions         = b.decisions;
        this.cbo               = b.cbo;
        this.cfgNodes          = b.cfgNodes;
        this.cfgEdges          = b.cfgEdges;
        this.hasSpaghettiCode  = b.hasSpaghettiCode;
        this.hasGodClass       = b.hasGodClass;
        this.smells            = List.copyOf(b.smells);
        this.logicHash         = b.logicHash;
        this.qualityScore      = b.qualityScore;
        this.qualityGrade      = b.qualityGrade;
    }

    public String getStudentId()          { return studentId; }
    public String getFileName()           { return fileName; }
    public String getFilePath()           { return filePath; }
    public LocalDateTime getAnalysedAt()  { return analysedAt; }
    public String getSubmissionKey()      { return submissionKey; }
    public int getVersionNumber()         { return versionNumber; }
    public int getPreviousVersionNumber() { return previousVersionNumber; }
    public int getUnchangedLineCount()    { return unchangedLineCount; }
    public int getModifiedLineCount()     { return modifiedLineCount; }
    public int getAddedLineCount()        { return addedLineCount; }
    public int getRemovedLineCount()      { return removedLineCount; }
    public int getTotalLines()            { return totalLines; }
    public int getCodeLines()             { return codeLines; }
    public int getCommentLines()          { return commentLines; }
    public int getClassCount()            { return classCount; }
    public int getMethodCount()           { return methodCount; }
    public int getFieldCount()            { return fieldCount; }
    public int getTotalCyclomaticComplexity() { return totalCC; }
    public double getAvgMethodComplexity()    { return avgCC; }
    public int getMaxMethodComplexity()       { return maxCC; }
    public String getMostComplexMethod()      { return mostComplexMethod; }
    public int getMaxNestingDepth()           { return maxNesting; }
    public double getAvgNestingDepth()        { return avgNesting; }
    public int getNumberOfDecisions()         { return decisions; }
    public int getCouplingBetweenObjects()    { return cbo; }
    public int getCfgNodes()                  { return cfgNodes; }
    public int getCfgEdges()                  { return cfgEdges; }
    public boolean isHasSpaghettiCode()       { return hasSpaghettiCode; }
    public boolean isHasGodClass()            { return hasGodClass; }
    public List<String> getDetectedSmells()   { return smells; }
    public String getLogicHash()              { return logicHash; }
    public int getQualityScore()              { return qualityScore; }
    public String getQualityGrade()           { return qualityGrade; }
    public String getVersionLabel()           { return "v" + versionNumber; }
    public boolean hasPreviousVersion()       { return previousVersionNumber > 0; }

    public static Builder builder() { return new Builder(); }

    public Builder toBuilder() {
        return new Builder()
            .studentId(studentId)
            .fileName(fileName)
            .filePath(filePath)
            .analysedAt(analysedAt)
            .submissionKey(submissionKey)
            .versionNumber(versionNumber)
            .previousVersionNumber(previousVersionNumber)
            .unchangedLineCount(unchangedLineCount)
            .modifiedLineCount(modifiedLineCount)
            .addedLineCount(addedLineCount)
            .removedLineCount(removedLineCount)
            .totalLines(totalLines)
            .codeLines(codeLines)
            .commentLines(commentLines)
            .classCount(classCount)
            .methodCount(methodCount)
            .fieldCount(fieldCount)
            .totalCC(totalCC)
            .avgCC(avgCC)
            .maxCC(maxCC)
            .mostComplexMethod(mostComplexMethod)
            .maxNesting(maxNesting)
            .avgNesting(avgNesting)
            .decisions(decisions)
            .cbo(cbo)
            .cfgNodes(cfgNodes)
            .cfgEdges(cfgEdges)
            .hasSpaghettiCode(hasSpaghettiCode)
            .hasGodClass(hasGodClass)
            .smells(new ArrayList<>(smells))
            .logicHash(logicHash)
            .qualityScore(qualityScore)
            .qualityGrade(qualityGrade);
    }

    public static final class Builder {
        private String studentId = "UNKNOWN";
        private String fileName = "";
        private String filePath = "";
        private LocalDateTime analysedAt = LocalDateTime.now();
        private String submissionKey = "";
        private int versionNumber = 1;
        private int previousVersionNumber = 0;
        private int unchangedLineCount;
        private int modifiedLineCount;
        private int addedLineCount;
        private int removedLineCount;
        private int totalLines, codeLines, commentLines;
        private int classCount, methodCount, fieldCount;
        private int totalCC;
        private double avgCC;
        private int maxCC;
        private String mostComplexMethod = "";
        private int maxNesting;
        private double avgNesting;
        private int decisions, cbo, cfgNodes, cfgEdges;
        private boolean hasSpaghettiCode, hasGodClass;
        private List<String> smells = new ArrayList<>();
        private String logicHash = "";
        private int qualityScore;
        private String qualityGrade = "N/A";

        public Builder studentId(String v)           { studentId = v; return this; }
        public Builder fileName(String v)            { fileName = v; return this; }
        public Builder filePath(String v)            { filePath = v; return this; }
        public Builder analysedAt(LocalDateTime v)   { analysedAt = v; return this; }
        public Builder submissionKey(String v)       { submissionKey = v; return this; }
        public Builder versionNumber(int v)          { versionNumber = v; return this; }
        public Builder previousVersionNumber(int v)  { previousVersionNumber = v; return this; }
        public Builder unchangedLineCount(int v)     { unchangedLineCount = v; return this; }
        public Builder modifiedLineCount(int v)      { modifiedLineCount = v; return this; }
        public Builder addedLineCount(int v)         { addedLineCount = v; return this; }
        public Builder removedLineCount(int v)       { removedLineCount = v; return this; }
        public Builder totalLines(int v)             { totalLines = v; return this; }
        public Builder codeLines(int v)              { codeLines = v; return this; }
        public Builder commentLines(int v)           { commentLines = v; return this; }
        public Builder classCount(int v)             { classCount = v; return this; }
        public Builder methodCount(int v)            { methodCount = v; return this; }
        public Builder fieldCount(int v)             { fieldCount = v; return this; }
        public Builder totalCC(int v)                { totalCC = v; return this; }
        public Builder avgCC(double v)               { avgCC = v; return this; }
        public Builder maxCC(int v)                  { maxCC = v; return this; }
        public Builder mostComplexMethod(String v)   { mostComplexMethod = v; return this; }
        public Builder maxNesting(int v)             { maxNesting = v; return this; }
        public Builder avgNesting(double v)          { avgNesting = v; return this; }
        public Builder decisions(int v)              { decisions = v; return this; }
        public Builder cbo(int v)                    { cbo = v; return this; }
        public Builder cfgNodes(int v)               { cfgNodes = v; return this; }
        public Builder cfgEdges(int v)               { cfgEdges = v; return this; }
        public Builder hasSpaghettiCode(boolean v)   { hasSpaghettiCode = v; return this; }
        public Builder hasGodClass(boolean v)        { hasGodClass = v; return this; }
        public Builder smells(List<String> v)        { smells = v; return this; }
        public Builder logicHash(String v)           { logicHash = v; return this; }
        public Builder qualityScore(int v)           { qualityScore = v; return this; }
        public Builder qualityGrade(String v)        { qualityGrade = v; return this; }
        public CodeMetrics build()                   { return new CodeMetrics(this); }
    }
}
