package com.lfcv.model;

import java.time.LocalDateTime;

// Represents one detected similarity case between two student submissions.
// The severity is automatically worked out from how similar they are.
public final class PlagiarismResult {

    public enum Severity { LOW, MEDIUM, HIGH, IDENTICAL }

    private final String studentIdA;
    private final String studentIdB;
    private final String fileA;
    private final String fileB;
    private final double similarityRatio;
    private final boolean exactHashMatch;
    private final Severity severity;
    private final LocalDateTime detectedAt;

    public PlagiarismResult(String studentIdA, String studentIdB,
                            String fileA, String fileB,
                            double similarityRatio, boolean exactHashMatch) {
        this.studentIdA      = studentIdA;
        this.studentIdB      = studentIdB;
        this.fileA           = fileA;
        this.fileB           = fileB;
        this.similarityRatio = similarityRatio;
        this.exactHashMatch  = exactHashMatch;
        this.detectedAt      = LocalDateTime.now();
        this.severity        = classifySeverity(similarityRatio, exactHashMatch);
    }

    private static Severity classifySeverity(double ratio, boolean exact) {
        if (exact)         return Severity.IDENTICAL;
        if (ratio >= 0.90) return Severity.HIGH;
        if (ratio >= 0.75) return Severity.MEDIUM;
        return Severity.LOW;
    }

    public String getStudentIdA()        { return studentIdA; }
    public String getStudentIdB()        { return studentIdB; }
    public String getFileA()             { return fileA; }
    public String getFileB()             { return fileB; }
    public double getSimilarityRatio()   { return similarityRatio; }
    public boolean isExactHashMatch()    { return exactHashMatch; }
    public Severity getSeverity()        { return severity; }
    public LocalDateTime getDetectedAt() { return detectedAt; }
    public String getSimilarityPercent() { return Math.round(similarityRatio * 100) + "%"; }
}
