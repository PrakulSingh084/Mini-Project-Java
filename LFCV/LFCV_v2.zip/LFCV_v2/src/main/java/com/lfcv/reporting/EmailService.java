package com.lfcv.reporting;

import com.lfcv.model.CodeMetrics;
import com.lfcv.model.PlagiarismResult;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.List;
import java.util.Properties;

// Sends analysis results directly to students or the professor by email.
// Uses JavaMail with SMTP - works with Gmail, Outlook, or any university mail server.
// The professor configures their SMTP settings once in the Email Settings dialog.
public class EmailService {

    private final String smtpHost;
    private final int    smtpPort;
    private final String username;
    private final String password;
    private final boolean useTls;

    public EmailService(String smtpHost, int smtpPort,
                        String username, String password, boolean useTls) {
        this.smtpHost = smtpHost;
        this.smtpPort = smtpPort;
        this.username = username;
        this.password = password;
        this.useTls   = useTls;
    }

    // Send a per-student feedback email with their full metrics breakdown
    public void sendStudentReport(CodeMetrics m, String toEmail) throws MessagingException {
        String subject = "LFCV Analysis Report — " + m.getStudentId() + " / " + m.getFileName();
        String body = buildStudentEmailBody(m);
        send(toEmail, subject, body);
    }

    // Send the professor a summary of all submissions, including any plagiarism flags
    public void sendProfessorSummary(List<CodeMetrics> submissions,
                                     List<PlagiarismResult> flags,
                                     String toEmail) throws MessagingException {
        String subject = "LFCV Cohort Summary — " + submissions.size() + " submissions";
        String body = buildSummaryEmailBody(submissions, flags);
        send(toEmail, subject, body);
    }

    // Test the connection — useful so professors can verify settings before a bulk send
    public void testConnection() throws MessagingException {
        Session session = buildSession();
        Transport transport = session.getTransport("smtp");
        transport.connect(smtpHost, smtpPort, username, password);
        transport.close();
    }

    private void send(String to, String subject, String body) throws MessagingException {
        Session session = buildSession();
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(username));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
        message.setSubject(subject);
        message.setText(body);
        Transport.send(message);
    }

    public void sendPlainText(String to, String subject, String body) throws MessagingException {
        send(to, subject, body);
    }

    private Session buildSession() {
        Properties props = new Properties();
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", String.valueOf(smtpPort));
        props.put("mail.smtp.auth", "true");
        if (useTls) {
            props.put("mail.smtp.starttls.enable", "true");
        } else {
            props.put("mail.smtp.ssl.enable", "true");
        }

        return Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });
    }

    private String buildStudentEmailBody(CodeMetrics m) {
        return """
            LFCV Automated Analysis Report
            ================================
            
            Student ID  : %s
            File        : %s
            Analysed at : %s
            
            CODE STRUCTURE
            ──────────────
            Total lines   : %d
            Code lines    : %d
            Comment lines : %d
            Classes       : %d
            Methods       : %d
            
            COMPLEXITY METRICS
            ──────────────────
            Total CC      : %d
            Average CC    : %.2f
            Max CC        : %d  (%s)
            Max nesting   : %d
            
            DESIGN SMELLS
            ─────────────
            %s
            
            QUALITY VERDICT
            ───────────────
            Score  : %d / 100
            Grade  : %s
            
            --
            Logic-Flow Code Visualizer (LFCV) v2.0
            This is an automated report. Please contact your professor with any queries.
            """.formatted(
                m.getStudentId(), m.getFileName(), m.getAnalysedAt(),
                m.getTotalLines(), m.getCodeLines(), m.getCommentLines(),
                m.getClassCount(), m.getMethodCount(),
                m.getTotalCyclomaticComplexity(), m.getAvgMethodComplexity(),
                m.getMaxMethodComplexity(), m.getMostComplexMethod(),
                m.getMaxNestingDepth(),
                m.getDetectedSmells().isEmpty() ? "None detected." : String.join("\n• ", m.getDetectedSmells()),
                m.getQualityScore(), m.getQualityGrade()
        );
    }

    private String buildSummaryEmailBody(List<CodeMetrics> subs, List<PlagiarismResult> flags) {
        long a = subs.stream().filter(m -> "A".equals(m.getQualityGrade())).count();
        long b = subs.stream().filter(m -> "B".equals(m.getQualityGrade())).count();
        long c = subs.stream().filter(m -> "C".equals(m.getQualityGrade())).count();
        long d = subs.stream().filter(m -> "D".equals(m.getQualityGrade())).count();
        long f = subs.stream().filter(m -> "F".equals(m.getQualityGrade())).count();
        double avgScore = subs.stream().mapToInt(CodeMetrics::getQualityScore).average().orElse(0);

        StringBuilder body = new StringBuilder();
        body.append("LFCV Cohort Summary Report\n");
        body.append("===========================\n\n");
        body.append("Submissions: ").append(subs.size()).append("\n");
        body.append("Avg score  : ").append(String.format("%.1f", avgScore)).append(" / 100\n\n");
        body.append("Grade Distribution:\n");
        body.append("  A: ").append(a).append("  B: ").append(b)
            .append("  C: ").append(c).append("  D: ").append(d)
            .append("  F: ").append(f).append("\n\n");

        if (!flags.isEmpty()) {
            body.append("INTEGRITY FLAGS (").append(flags.size()).append(" pair(s))\n");
            body.append("─────────────────────────────────\n");
            for (PlagiarismResult r : flags) {
                body.append(String.format("  [%s] %s ↔ %s  (%s)%s%n",
                    r.getSeverity(), r.getStudentIdA(), r.getStudentIdB(),
                    r.getSimilarityPercent(),
                    r.isExactHashMatch() ? " *** IDENTICAL ***" : ""));
            }
        } else {
            body.append("No integrity flags.\n");
        }

        body.append("\n--\nLogic-Flow Code Visualizer (LFCV) v2.0");
        return body.toString();
    }
}
