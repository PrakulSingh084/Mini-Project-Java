package com.lfcv.reporting;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.lfcv.model.CodeMetrics;
import com.lfcv.model.PlagiarismResult;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

// Handles all the export work: CSV gradebooks, JSON for LMS integration,
// summary text reports, and per-student detailed breakdowns.
public class ReportGenerator {

    private static final DateTimeFormatter DT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public Path exportGradebookCsv(List<CodeMetrics> subs, Path out) throws IOException {
        String[] headers = {
            "Student ID","File","Analysed At","Total Lines","Code Lines","Comment Lines",
            "Classes","Methods","Fields","Total CC","Avg CC","Max CC","Most Complex Method",
            "Max Nesting","Avg Nesting","CBO","CFG Nodes","CFG Edges",
            "Spaghetti","God Class","Smells","Logic Hash","Score","Grade"
        };
        try (Writer w = new FileWriter(out.toFile(), StandardCharsets.UTF_8);
             CSVPrinter p = new CSVPrinter(w, CSVFormat.DEFAULT.builder().setHeader(headers).build())) {
            for (CodeMetrics m : subs) {
                p.printRecord(
                    m.getStudentId(), m.getFileName(), m.getAnalysedAt().format(DT),
                    m.getTotalLines(), m.getCodeLines(), m.getCommentLines(),
                    m.getClassCount(), m.getMethodCount(), m.getFieldCount(),
                    m.getTotalCyclomaticComplexity(), String.format("%.2f", m.getAvgMethodComplexity()),
                    m.getMaxMethodComplexity(), m.getMostComplexMethod(),
                    m.getMaxNestingDepth(), String.format("%.2f", m.getAvgNestingDepth()),
                    m.getCouplingBetweenObjects(), m.getCfgNodes(), m.getCfgEdges(),
                    m.isHasSpaghettiCode() ? "YES" : "no",
                    m.isHasGodClass() ? "YES" : "no",
                    m.getDetectedSmells().size(),
                    m.getLogicHash(), m.getQualityScore(), m.getQualityGrade()
                );
            }
        }
        return out;
    }

    public Path exportPlagiarismCsv(List<PlagiarismResult> flags, Path out) throws IOException {
        String[] headers = {"Student A","Student B","File A","File B","Similarity","Exact Match","Severity","Detected At"};
        try (Writer w = new FileWriter(out.toFile(), StandardCharsets.UTF_8);
             CSVPrinter p = new CSVPrinter(w, CSVFormat.DEFAULT.builder().setHeader(headers).build())) {
            for (PlagiarismResult r : flags) {
                p.printRecord(r.getStudentIdA(), r.getStudentIdB(), r.getFileA(), r.getFileB(),
                    r.getSimilarityPercent(), r.isExactHashMatch() ? "YES" : "no",
                    r.getSeverity().name(), r.getDetectedAt().format(DT));
            }
        }
        return out;
    }

    public Path exportJson(List<CodeMetrics> subs, List<PlagiarismResult> flags, Path out) throws IOException {
        JsonObject root = new JsonObject();
        root.addProperty("exportedAt", LocalDateTime.now().toString());
        root.addProperty("lfcvVersion", "2.0.0");
        root.addProperty("totalSubmissions", subs.size());

        JsonArray subArr = new JsonArray();
        for (CodeMetrics m : subs) {
            JsonObject obj = new JsonObject();
            obj.addProperty("studentId",    m.getStudentId());
            obj.addProperty("fileName",     m.getFileName());
            obj.addProperty("totalCC",      m.getTotalCyclomaticComplexity());
            obj.addProperty("avgCC",        m.getAvgMethodComplexity());
            obj.addProperty("maxNesting",   m.getMaxNestingDepth());
            obj.addProperty("logicHash",    m.getLogicHash());
            obj.addProperty("score",        m.getQualityScore());
            obj.addProperty("grade",        m.getQualityGrade());
            subArr.add(obj);
        }
        root.add("submissions", subArr);

        JsonArray flagArr = new JsonArray();
        for (PlagiarismResult r : flags) {
            JsonObject obj = new JsonObject();
            obj.addProperty("studentA",    r.getStudentIdA());
            obj.addProperty("studentB",    r.getStudentIdB());
            obj.addProperty("similarity",  r.getSimilarityPercent());
            obj.addProperty("exactMatch",  r.isExactHashMatch());
            obj.addProperty("severity",    r.getSeverity().name());
            flagArr.add(obj);
        }
        root.add("plagiarismFlags", flagArr);

        Files.writeString(out, new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        return out;
    }

    public Path exportSummaryText(List<CodeMetrics> subs, List<PlagiarismResult> flags, Path out) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(out.toFile(), StandardCharsets.UTF_8))) {
            pw.println("=".repeat(65));
            pw.println("  LOGIC-FLOW CODE VISUALIZER (LFCV) v2.0 — ANALYSIS SUMMARY");
            pw.println("  Generated: " + LocalDateTime.now().format(DT));
            pw.println("=".repeat(65));
            pw.println();

            int n = subs.size();
            double avgScore = subs.stream().mapToInt(CodeMetrics::getQualityScore).average().orElse(0);
            pw.printf("Submissions     : %d%n", n);
            pw.printf("Avg Score       : %.1f / 100%n", avgScore);
            pw.printf("Integrity Flags : %d pair(s)%n", flags.size());
            pw.println();

            pw.println("GRADE DISTRIBUTION");
            pw.println("-".repeat(30));
            for (String g : List.of("A","B","C","D","F")) {
                long cnt = subs.stream().filter(m -> g.equals(m.getQualityGrade())).count();
                pw.printf("  %s : %d%n", g, cnt);
            }
            pw.println();

            if (!flags.isEmpty()) {
                pw.println("INTEGRITY FLAGS");
                pw.println("-".repeat(30));
                for (PlagiarismResult r : flags) {
                    pw.printf("  [%s] %s ↔ %s (%s)%s%n",
                        r.getSeverity(), r.getStudentIdA(), r.getStudentIdB(),
                        r.getSimilarityPercent(), r.isExactHashMatch() ? " *** IDENTICAL ***" : "");
                }
                pw.println();
            }

            pw.println("PER-STUDENT RESULTS");
            pw.println("-".repeat(65));
            pw.printf("  %-15s %-20s %5s %5s %6s%n", "Student ID", "File", "CC", "Nest", "Grade");
            pw.println("  " + "-".repeat(55));
            for (CodeMetrics m : subs) {
                pw.printf("  %-15s %-20s %5d %5d %6s%n",
                    m.getStudentId(), truncate(m.getFileName(), 20),
                    m.getTotalCyclomaticComplexity(), m.getMaxNestingDepth(), m.getQualityGrade());
            }
        }
        return out;
    }

    private String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }
}
