package com.lfcv.ui;

import com.lfcv.analysis.AnalysisEngine;
import com.lfcv.bulk.BulkProcessor;
import com.lfcv.comparison.DiffLine;
import com.lfcv.comparison.LineChangeType;
import com.lfcv.comparison.VersionDiffResult;
import com.lfcv.comparison.VersionHistoryService;
import com.lfcv.integrity.IntegrityService;
import com.lfcv.model.CfgNode;
import com.lfcv.model.CodeMetrics;
import com.lfcv.model.PlagiarismResult;
import com.lfcv.reporting.EmailService;
import com.lfcv.reporting.ReportGenerator;
import com.lfcv.visualization.CfgVisualizer;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import javafx.util.Callback;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;

import java.io.File;
import java.net.URL;
import java.nio.file.Paths;
import java.util.concurrent.ConcurrentHashMap;
import java.util.*;

// The brain of the user interface.
// Every button click, table selection, and tab switch is handled here.
// This controller talks to the analysis, integrity, and reporting services,
// then pushes results back into the UI widgets.
public class MainController implements Initializable {

    // ── Services ──────────────────────────────────────────────────────────────
    private final AnalysisEngine   engine    = new AnalysisEngine();
    private final IntegrityService integrity = new IntegrityService();
    private final BulkProcessor    bulk      = new BulkProcessor();
    private final ReportGenerator  reports   = new ReportGenerator();
    private final CfgVisualizer    cfgDraw   = new CfgVisualizer();
    private final VersionHistoryService versionHistory = new VersionHistoryService();

    // ── Live data lists — bound directly to the JavaFX tables ─────────────────
    private final ObservableList<CodeMetrics>      submissions = FXCollections.observableArrayList();
    private final ObservableList<PlagiarismResult> plagiarism  = FXCollections.observableArrayList();
    private final ObservableList<DiffLine> comparisonLines     = FXCollections.observableArrayList();
    private final Map<String, VersionDiffResult> comparisonCache = new ConcurrentHashMap<>();
    private final Map<String, List<String>> versionLabelsCache   = new ConcurrentHashMap<>();

    // ── FXML bindings: toolbar ────────────────────────────────────────────────
    @FXML private Button      btnAnalyse;
    @FXML private Button      btnBulkScan;
    @FXML private Button      btnIntegrity;
    @FXML private Button      btnEmail;
    @FXML private Label       lblStatus;
    @FXML private ProgressBar progressBar;
    @FXML private Label       lblProgress;

    // ── FXML bindings: submissions table ──────────────────────────────────────
    @FXML private TableView<CodeMetrics>           tableSubmissions;
    @FXML private TableColumn<CodeMetrics,String>  colStudent;
    @FXML private TableColumn<CodeMetrics,String>  colFile;
    @FXML private TableColumn<CodeMetrics,String>  colVersion;
    @FXML private TableColumn<CodeMetrics,Integer> colCC;
    @FXML private TableColumn<CodeMetrics,Integer> colNesting;
    @FXML private TableColumn<CodeMetrics,Integer> colScore;
    @FXML private TableColumn<CodeMetrics,String>  colGrade;
    @FXML private TableColumn<CodeMetrics,Boolean> colSpaghetti;
    @FXML private TableColumn<CodeMetrics,Boolean> colGodClass;

    // ── FXML bindings: detail panel ───────────────────────────────────────────
    @FXML private Label   lblDetailStudent;
    @FXML private Label   lblDetailFile;
    @FXML private Label   lblDetailCC;
    @FXML private Label   lblDetailNesting;
    @FXML private Label   lblDetailGrade;
    @FXML private Label   lblDetailHash;
    @FXML private Label   lblDetailVersion;
    @FXML private Label   lblDetailCompare;
    @FXML private TextArea txaSmells;
    @FXML private ListView<String> listVersionHistory;

    // ── FXML bindings: CFG tab ────────────────────────────────────────────────
    @FXML private ScrollPane scrollCfg;
    @FXML private StackPane  cfgHolder;
    @FXML private Label      lblCfgStats;
    @FXML private Label      lblCfgMethod;
    @FXML private ComboBox<CodeMetrics> cmbCfgSubmission;
    @FXML private Button btnRenderCfg;

    // ── FXML bindings: integrity table ───────────────────────────────────────
    @FXML private TableView<PlagiarismResult>           tablePlagiarism;
    @FXML private TableColumn<PlagiarismResult,String>  colPlagA;
    @FXML private TableColumn<PlagiarismResult,String>  colPlagB;
    @FXML private TableColumn<PlagiarismResult,String>  colPlagSim;
    @FXML private TableColumn<PlagiarismResult,String>  colPlagSev;
    @FXML private TableColumn<PlagiarismResult,Boolean> colPlagExact;

    // ── FXML bindings: export buttons ────────────────────────────────────────
    @FXML private Button btnExportCsv;
    @FXML private Button btnExportJson;
    @FXML private Button btnExportSummary;

    // ── FXML bindings: KPI badges ─────────────────────────────────────────────
    @FXML private FlowPane badgeRow;
    @FXML private Label lblCompareSummary;
    @FXML private TableView<DiffLine> tableComparison;
    @FXML private TableColumn<DiffLine, String> colOldLine;
    @FXML private TableColumn<DiffLine, String> colNewLine;
    @FXML private TableColumn<DiffLine, String> colChangeType;
    @FXML private TableColumn<DiffLine, String> colCodePreview;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupSubmissionsTable();
        setupPlagiarismTable();
        setupComparisonTable();
        setupCfgSelector();
        bindBulkProgress();
        setStatus("Ready — load a .java file or scan a folder to begin.");
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  TOOLBAR ACTIONS
    // ═════════════════════════════════════════════════════════════════════════

    @FXML
    private void handleAnalyse() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Select a Java source file");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Java Files", "*.java"));
        File file = fc.showOpenDialog(getStage());
        if (file == null) return;

        String sid = askStudentId(file.getName()).orElse("UNKNOWN");
        setStatus("Analysing " + file.getName() + "...");

        new Thread(() -> {
            try {
                CodeMetrics m = registerVersionedMetrics(file, sid, engine.analyse(file, sid));
                Platform.runLater(() -> {
                    submissions.add(m);
                    syncCfgSelectorItems();
                    tableSubmissions.getSelectionModel().selectLast();
                    refreshBadges();
                    setStatus("Done — " + file.getName() + " " + m.getVersionLabel() + "  |  Grade: "
                        + m.getQualityGrade() + "  |  CC: " + m.getTotalCyclomaticComplexity());
                });
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    showError("Analysis Failed", ex.getMessage());
                    setStatus("Analysis failed.");
                });
            }
        }, "analysis-thread").start();
    }

    @FXML
    private void handleBulkScan() {
        DirectoryChooser dc = new DirectoryChooser();
        dc.setTitle("Select Submissions Folder");
        File folder = dc.showDialog(getStage());
        if (folder == null) return;

        btnBulkScan.setDisable(true);
        setStatus("Bulk scanning: " + folder.getName() + "...");

        bulk.processFolder(folder,
            results -> {
                List<CodeMetrics> versionedResults = new ArrayList<>();
                for (CodeMetrics result : results) {
                    try {
                        versionedResults.add(registerVersionedMetrics(
                            new File(result.getFilePath()), result.getStudentId(), result));
                    } catch (Exception ex) {
                        System.err.println("Could not register version history for "
                            + result.getFileName() + ": " + ex.getMessage());
                        versionedResults.add(result);
                    }
                }
                submissions.addAll(versionedResults);
                syncCfgSelectorItems();
                refreshBadges();
                btnBulkScan.setDisable(false);
                setStatus("Bulk scan complete — " + versionedResults.size() + " files analysed.");
            },
            error -> {
                showError("Scan Error", error);
                btnBulkScan.setDisable(false);
                setStatus("Bulk scan failed.");
            }
        );
    }

    @FXML
    private void handleIntegrity() {
        if (submissions.size() < 2) {
            showInfo("Not enough data", "Load at least 2 submissions before running an integrity check.");
            return;
        }
        setStatus("Running integrity check across " + submissions.size() + " submissions...");

        new Thread(() -> {
            List<PlagiarismResult> results = integrity.detectAll(new ArrayList<>(submissions));
            Platform.runLater(() -> {
                plagiarism.setAll(results);
                refreshBadges();
                setStatus(results.isEmpty()
                    ? "Integrity check complete — no suspicious matches found."
                    : "⚠  Flagged " + results.size() + " suspicious pair(s)!");
            });
        }, "integrity-thread").start();
    }

    // Opens the email configuration dialog where the professor can set up SMTP and send reports
    @FXML
    private void handleEmailSettings() {
        Dialog<ButtonType> dlg = new Dialog<>();
        dlg.setTitle("Email Configuration");
        dlg.setHeaderText("Configure SMTP to send reports by email.");

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(8);
        grid.setPadding(new Insets(16));
        grid.setStyle("-fx-background-color:#161b22;");

        TextField     fHost = styledField("smtp.gmail.com");
        TextField     fPort = styledField("587");
        TextField     fUser = styledField("your@email.com");
        PasswordField fPass = new PasswordField();
        fPass.setPromptText("app password");
        applyFieldStyle(fPass);
        TextField fTo   = styledField("professor@university.edu");
        CheckBox  cbTls = new CheckBox("Use STARTTLS");
        cbTls.setSelected(true);
        cbTls.setStyle("-fx-text-fill:#c9d1d9;");

        addFormRow(grid, "SMTP Host:", fHost, 0);
        addFormRow(grid, "SMTP Port:", fPort, 1);
        addFormRow(grid, "Username:",  fUser, 2);
        addFormRow(grid, "Password:",  fPass, 3);
        addFormRow(grid, "Send to:",   fTo,   4);
        grid.add(cbTls, 1, 5);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().setStyle("-fx-background-color:#0d1117;");

        ButtonType sendType = new ButtonType("Send Reports", ButtonBar.ButtonData.OK_DONE);
        ButtonType testType = new ButtonType("Test Connection", ButtonBar.ButtonData.OTHER);
        dlg.getDialogPane().getButtonTypes().addAll(sendType, testType, ButtonType.CANCEL);

        dlg.showAndWait().ifPresent(bt -> {
            if (bt == ButtonType.CANCEL) return;
            try {
                EmailService email = new EmailService(
                    fHost.getText().trim(),
                    Integer.parseInt(fPort.getText().trim()),
                    fUser.getText().trim(),
                    fPass.getText(),
                    cbTls.isSelected()
                );

                if (bt == testType) {
                    new Thread(() -> {
                        try {
                            email.testConnection();
                            Platform.runLater(() -> showInfo("Connection OK", "SMTP connection successful!"));
                        } catch (Exception ex) {
                            Platform.runLater(() -> showError("Connection Failed", ex.getMessage()));
                        }
                    }, "email-test").start();
                } else {
                    String to = fTo.getText().trim();
                    new Thread(() -> {
                        try {
                            for (CodeMetrics m : new ArrayList<>(submissions))
                                email.sendStudentReport(m, to);
                            email.sendProfessorSummary(
                                new ArrayList<>(submissions), new ArrayList<>(plagiarism), to);
                            Platform.runLater(() -> {
                                showInfo("Sent", "All reports sent to " + to);
                                setStatus("Email reports sent.");
                            });
                        } catch (Exception ex) {
                            Platform.runLater(() -> showError("Email Failed", ex.getMessage()));
                        }
                    }, "email-send").start();
                }
            } catch (NumberFormatException ex) {
                showError("Invalid Port", "Port must be a number (e.g. 587).");
            }
        });
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  CFG TAB — renders the Control Flow Graph for the selected submission
    // ═════════════════════════════════════════════════════════════════════════

    private void loadCfgForSubmission(CodeMetrics m) {
        if (m == null) return;
        if (lblCfgMethod != null)
            lblCfgMethod.setText("Rendering CFG for: " + m.getFileName() + "...");

        new Thread(() -> {
            try {
                Graph<CfgNode, DefaultEdge> graph = engine.buildCfg(new File(m.getFilePath()));
                if (graph == null) return;

                int nodes = graph.vertexSet().size();
                int edges = graph.edgeSet().size();
                // McCabe's formula applied to the actual graph as a cross-check
                int cfgCC = Math.max(1, edges - nodes + 2);

                VersionDiffResult diff = comparisonFor(m);
                Canvas canvas = cfgDraw.render(graph, new CfgVisualizer.RenderContext(
                    diff == null ? Set.of() : diff.highlightedLineNumbers(),
                    m.getVersionNumber(),
                    true
                ));

                Platform.runLater(() -> {
                    if (cfgHolder  != null) cfgHolder.getChildren().setAll(canvas);
                    if (lblCfgStats != null)
                        lblCfgStats.setText(
                            "Nodes: " + nodes + "   Edges: " + edges
                            + "   CC via E−N+2: " + cfgCC
                            + "   Changed Lines: " + m.getModifiedLineCount()
                            + "   Added Lines: " + m.getAddedLineCount()
                            + "   Visitor CC: " + m.getTotalCyclomaticComplexity());
                    if (lblCfgMethod != null)
                        lblCfgMethod.setText(m.getFileName() + "  —  " + m.getStudentId() + "  —  "
                            + m.getVersionLabel() + "  —  Accent palette: " + versionPaletteName(m.getVersionNumber()));
                });

            } catch (Exception ex) {
                Platform.runLater(() -> {
                    if (lblCfgStats != null)
                        lblCfgStats.setText("Could not render CFG: " + ex.getMessage());
                });
            }
        }, "cfg-render").start();
    }

    @FXML private void handleZoomIn()    { scaleCfg(1.25); }
    @FXML private void handleZoomOut()   { scaleCfg(0.80); }
    @FXML private void handleRenderCfg() {
        CodeMetrics selected = selectedCfgSubmission();
        if (selected == null) {
            showInfo("No Submission Selected", "Choose a submission in the CFG tab dropdown first.");
            return;
        }
        loadCfgForSubmission(selected);
    }
    @FXML private void handleZoomReset() {
        if (cfgHolder != null) { cfgHolder.setScaleX(1); cfgHolder.setScaleY(1); }
    }

    private void scaleCfg(double factor) {
        if (cfgHolder == null) return;
        double nx = Math.max(0.2, Math.min(4.0, cfgHolder.getScaleX() * factor));
        cfgHolder.setScaleX(nx);
        cfgHolder.setScaleY(nx);
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  EXPORT ACTIONS
    // ═════════════════════════════════════════════════════════════════════════

    @FXML
    private void handleExportCsv() {
        if (submissions.isEmpty()) { showNoData(); return; }
        File f = saveDialog("CSV Files", "*.csv", "lfcv_gradebook.csv");
        if (f == null) return;
        try {
            reports.exportGradebookCsv(new ArrayList<>(submissions), f.toPath());
            if (!plagiarism.isEmpty())
                reports.exportPlagiarismCsv(new ArrayList<>(plagiarism),
                    Paths.get(f.getParent(), "lfcv_plagiarism.csv"));
            setStatus("CSV exported → " + f.getName());
        } catch (Exception ex) { showError("Export Failed", ex.getMessage()); }
    }

    @FXML
    private void handleExportJson() {
        if (submissions.isEmpty()) { showNoData(); return; }
        File f = saveDialog("JSON Files", "*.json", "lfcv_results.json");
        if (f == null) return;
        try {
            reports.exportJson(new ArrayList<>(submissions), new ArrayList<>(plagiarism), f.toPath());
            setStatus("JSON exported → " + f.getName());
        } catch (Exception ex) { showError("Export Failed", ex.getMessage()); }
    }

    @FXML
    private void handleExportSummary() {
        if (submissions.isEmpty()) { showNoData(); return; }
        File f = saveDialog("Text Files", "*.txt", "lfcv_summary.txt");
        if (f == null) return;
        try {
            reports.exportSummaryText(new ArrayList<>(submissions), new ArrayList<>(plagiarism), f.toPath());
            setStatus("Summary exported → " + f.getName());
        } catch (Exception ex) { showError("Export Failed", ex.getMessage()); }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  TABLE SETUP
    // ═════════════════════════════════════════════════════════════════════════

    private void setupSubmissionsTable() {
        if (tableSubmissions == null) return;

        colStudent.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colFile.setCellValueFactory(new PropertyValueFactory<>("fileName"));
        colVersion.setCellValueFactory(new PropertyValueFactory<>("versionLabel"));
        colCC.setCellValueFactory(new PropertyValueFactory<>("totalCyclomaticComplexity"));
        colNesting.setCellValueFactory(new PropertyValueFactory<>("maxNestingDepth"));
        colScore.setCellValueFactory(new PropertyValueFactory<>("qualityScore"));
        colGrade.setCellValueFactory(new PropertyValueFactory<>("qualityGrade"));
        colSpaghetti.setCellValueFactory(new PropertyValueFactory<>("hasSpaghettiCode"));
        colGodClass.setCellValueFactory(new PropertyValueFactory<>("hasGodClass"));

        // Grade column: green for A/B, amber for C, red for D/F
        colGrade.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String g, boolean empty) {
                super.updateItem(g, empty);
                if (empty || g == null) { setText(null); setStyle(""); return; }
                setText(g);
                setStyle(switch (g) {
                    case "A" -> "-fx-text-fill:#3fb950; -fx-font-weight:bold;";
                    case "B" -> "-fx-text-fill:#56d364;";
                    case "C" -> "-fx-text-fill:#e3b341;";
                    case "D" -> "-fx-text-fill:#e67e22;";
                    default  -> "-fx-text-fill:#f85149; -fx-font-weight:bold;";
                });
            }
        });

        colSpaghetti.setCellFactory(boolCell("⚠ YES", "✓"));
        colGodClass.setCellFactory(boolCell("⚠ YES", "✓"));

        tableSubmissions.setItems(submissions);

        // When a row is selected: update the detail panel and fire the CFG render
        tableSubmissions.getSelectionModel().selectedItemProperty()
            .addListener((obs, old, selected) -> {
                updateDetailPanel(selected);
                if (cmbCfgSubmission != null && selected != null) {
                    cmbCfgSubmission.getSelectionModel().select(selected);
                }
                loadCfgForSubmission(selected);
                loadComparisonForSubmission(selected);
            });
    }

    private void setupPlagiarismTable() {
        if (tablePlagiarism == null) return;

        colPlagA.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStudentIdA()));
        colPlagB.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStudentIdB()));
        colPlagSim.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getSimilarityPercent()));
        colPlagSev.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getSeverity().name()));
        colPlagExact.setCellValueFactory(c ->
            new javafx.beans.property.SimpleBooleanProperty(c.getValue().isExactHashMatch()).asObject());

        // Severity column colour-coding: IDENTICAL is bright red, HIGH is orange
        colPlagSev.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String sev, boolean empty) {
                super.updateItem(sev, empty);
                if (empty || sev == null) { setText(null); return; }
                setText(sev);
                setStyle(switch (sev) {
                    case "IDENTICAL" -> "-fx-text-fill:#f85149; -fx-font-weight:bold;";
                    case "HIGH"      -> "-fx-text-fill:#e67e22; -fx-font-weight:bold;";
                    case "MEDIUM"    -> "-fx-text-fill:#e3b341;";
                    default          -> "-fx-text-fill:#c9d1d9;";
                });
            }
        });

        tablePlagiarism.setItems(plagiarism);
    }

    private void setupComparisonTable() {
        if (tableComparison == null) return;

        colOldLine.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().oldLineNumber() == null ? "—" : String.valueOf(c.getValue().oldLineNumber())));
        colNewLine.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().newLineNumber() == null ? "—" : String.valueOf(c.getValue().newLineNumber())));
        colChangeType.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().changeType().name()));
        colCodePreview.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().displayContent()));

        colChangeType.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String value, boolean empty) {
                super.updateItem(value, empty);
                if (empty || value == null) {
                    setText(null);
                    setStyle("");
                    return;
                }
                setText(value);
                setStyle(switch (LineChangeType.valueOf(value)) {
                    case UNCHANGED -> "-fx-text-fill:#8b949e;";
                    case MODIFIED -> "-fx-text-fill:#58a6ff; -fx-font-weight:bold;";
                    case ADDED -> "-fx-text-fill:#3fb950; -fx-font-weight:bold;";
                    case REMOVED -> "-fx-text-fill:#f85149; -fx-font-weight:bold;";
                });
            }
        });

        colCodePreview.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String value, boolean empty) {
                super.updateItem(value, empty);
                if (empty || value == null) {
                    setText(null);
                    setStyle("");
                    return;
                }
                setText(value);
                DiffLine line = getTableRow() == null ? null : getTableRow().getItem();
                String color = line == null ? "#c9d1d9" : switch (line.changeType()) {
                    case UNCHANGED -> "#c9d1d9";
                    case MODIFIED -> "#79c0ff";
                    case ADDED -> "#56d364";
                    case REMOVED -> "#ff7b72";
                };
                setStyle("-fx-text-fill:" + color + "; -fx-font-family:'Consolas';");
            }
        });

        tableComparison.setItems(comparisonLines);
    }

    private void setupCfgSelector() {
        if (cmbCfgSubmission == null) return;
        cmbCfgSubmission.setItems(submissions);
        cmbCfgSubmission.setConverter(new StringConverter<>() {
            @Override
            public String toString(CodeMetrics metrics) {
                if (metrics == null) return "";
                return metrics.getStudentId() + "  •  " + metrics.getFileName() + "  •  " + metrics.getVersionLabel();
            }

            @Override
            public CodeMetrics fromString(String string) {
                return null;
            }
        });
        cmbCfgSubmission.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> {
            if (selected == null) return;
            if (tableSubmissions != null && tableSubmissions.getSelectionModel().getSelectedItem() != selected) {
                tableSubmissions.getSelectionModel().select(selected);
            } else {
                loadCfgForSubmission(selected);
                loadComparisonForSubmission(selected);
            }
        });
    }

    private void syncCfgSelectorItems() {
        if (cmbCfgSubmission == null) return;
        cmbCfgSubmission.setItems(submissions);
        if (!submissions.isEmpty() && cmbCfgSubmission.getSelectionModel().getSelectedItem() == null) {
            cmbCfgSubmission.getSelectionModel().selectLast();
        }
    }

    private void updateDetailPanel(CodeMetrics m) {
        if (m == null) return;
        if (lblDetailStudent != null) lblDetailStudent.setText(m.getStudentId());
        if (lblDetailFile    != null) lblDetailFile.setText(m.getFileName());
        if (lblDetailCC      != null) lblDetailCC.setText(m.getTotalCyclomaticComplexity()
            + "  (avg: " + String.format("%.1f", m.getAvgMethodComplexity()) + ")");
        if (lblDetailNesting != null) lblDetailNesting.setText(m.getMaxNestingDepth()
            + "  (avg: " + String.format("%.1f", m.getAvgNestingDepth()) + ")");
        if (lblDetailGrade   != null)
            lblDetailGrade.setText(m.getQualityGrade() + "  (" + m.getQualityScore() + "/100)");
        if (lblDetailHash    != null)
            lblDetailHash.setText(m.getLogicHash().substring(0, 16) + "...");
        if (lblDetailVersion != null)
            lblDetailVersion.setText(m.getVersionLabel()
                + (m.hasPreviousVersion() ? "  (previous: v" + m.getPreviousVersionNumber() + ")" : "  (baseline capture)"));
        if (lblDetailCompare != null)
            lblDetailCompare.setText("same: " + m.getUnchangedLineCount()
                + "  modified: " + m.getModifiedLineCount()
                + "  added: " + m.getAddedLineCount()
                + "  removed: " + m.getRemovedLineCount());
        if (txaSmells != null)
            txaSmells.setText(m.getDetectedSmells().isEmpty()
                ? "✓  No smells detected."
                : "• " + String.join("\n• ", m.getDetectedSmells()));
        if (listVersionHistory != null) {
            listVersionHistory.getItems().setAll(
                versionLabelsCache.getOrDefault(m.getSubmissionKey(), List.of(m.getVersionLabel())));
        }
        if (cmbCfgSubmission != null && cmbCfgSubmission.getSelectionModel().getSelectedItem() != m) {
            cmbCfgSubmission.getSelectionModel().select(m);
        }
    }

    private void loadComparisonForSubmission(CodeMetrics m) {
        if (m == null) return;
        VersionDiffResult diff = comparisonFor(m);
        if (diff == null) {
            comparisonLines.clear();
            if (lblCompareSummary != null) {
                lblCompareSummary.setText("No comparison data available for this submission.");
            }
            return;
        }
        comparisonLines.setAll(diff.lines());
        if (lblCompareSummary != null) {
            lblCompareSummary.setText(diff.summary());
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  KPI BADGES — the coloured stat tiles at the top of the screen
    // ═════════════════════════════════════════════════════════════════════════

    private void refreshBadges() {
        if (badgeRow == null) return;
        badgeRow.getChildren().clear();
        if (submissions.isEmpty()) return;

        int    n        = submissions.size();
        double avgScore = submissions.stream().mapToInt(CodeMetrics::getQualityScore).average().orElse(0);
        double avgCC    = submissions.stream().mapToDouble(CodeMetrics::getAvgMethodComplexity).average().orElse(0);
        long   spag     = submissions.stream().filter(CodeMetrics::isHasSpaghettiCode).count();
        long   gradeA   = submissions.stream().filter(m -> "A".equals(m.getQualityGrade())).count();
        long   gradeF   = submissions.stream().filter(m -> "F".equals(m.getQualityGrade())).count();
        int    flags    = plagiarism.size();

        badgeRow.getChildren().addAll(
            makeBadge("Submissions",     String.valueOf(n),              "#3fb950", "analysed"),
            makeBadge("Avg Score",       String.format("%.0f", avgScore),
                avgScore >= 70 ? "#3fb950" : avgScore >= 50 ? "#e3b341" : "#f85149", "/ 100"),
            makeBadge("Avg CC",          String.format("%.1f", avgCC),
                avgCC <= 5 ? "#3fb950" : avgCC <= 10 ? "#e3b341" : "#f85149", "per method"),
            makeBadge("Grade A",         String.valueOf(gradeA), "#3fb950", "submissions"),
            makeBadge("Grade F",         String.valueOf(gradeF), gradeF > 0 ? "#f85149" : "#3fb950", "submissions"),
            makeBadge("Spaghetti Code",  String.valueOf(spag),   spag > 0 ? "#e67e22" : "#3fb950", "flagged"),
            makeBadge("Integrity Flags", String.valueOf(flags),  flags > 0 ? "#f85149" : "#3fb950", "pair(s)")
        );
    }

    private VBox makeBadge(String label, String value, String colour, String sub) {
        VBox box = new VBox(3);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(14, 20, 14, 20));
        box.setMinWidth(130);
        box.setStyle("-fx-background-color:#161b22; -fx-border-color:#30363d; "
            + "-fx-border-width:1; -fx-border-radius:8; -fx-background-radius:8;");

        Label lbl = new Label(label);
        lbl.setStyle("-fx-text-fill:#8b949e; -fx-font-size:11px; -fx-font-weight:bold;");

        Label val = new Label(value);
        val.setStyle("-fx-text-fill:" + colour + "; -fx-font-size:26px; "
            + "-fx-font-weight:bold; -fx-font-family:'Consolas';");

        Label s = new Label(sub);
        s.setStyle("-fx-text-fill:#6e7681; -fx-font-size:10px;");

        box.getChildren().addAll(lbl, val, s);
        return box;
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  UTILITY HELPERS
    // ═════════════════════════════════════════════════════════════════════════

    private void bindBulkProgress() {
        if (progressBar != null) progressBar.progressProperty().bind(bulk.progressProperty());
        if (lblProgress  != null) lblProgress.textProperty().bind(bulk.statusProperty());
    }

    private void setStatus(String msg) {
        if (lblStatus != null) lblStatus.setText(msg);
    }

    private CodeMetrics registerVersionedMetrics(File file, String studentId, CodeMetrics baseMetrics) throws Exception {
        VersionHistoryService.VersionRegistration registration =
            versionHistory.register(file, studentId, baseMetrics);
        CodeMetrics metrics = registration.metrics();
        comparisonCache.put(comparisonKey(metrics), registration.diffResult());
        versionLabelsCache.put(metrics.getSubmissionKey(), registration.versionLabels());
        return metrics;
    }

    private VersionDiffResult comparisonFor(CodeMetrics metrics) {
        return comparisonCache.get(comparisonKey(metrics));
    }

    private String comparisonKey(CodeMetrics metrics) {
        return metrics.getSubmissionKey() + "#v" + metrics.getVersionNumber();
    }

    private CodeMetrics selectedCfgSubmission() {
        return cmbCfgSubmission == null ? tableSubmissions.getSelectionModel().getSelectedItem()
            : cmbCfgSubmission.getSelectionModel().getSelectedItem();
    }

    private String versionPaletteName(int versionNumber) {
        return switch (Math.floorMod(versionNumber - 1, 5)) {
            case 0 -> "Blue";
            case 1 -> "Green";
            case 2 -> "Amber";
            case 3 -> "Violet";
            default -> "Coral";
        };
    }

    private Stage getStage() {
        return (btnAnalyse != null && btnAnalyse.getScene() != null)
            ? (Stage) btnAnalyse.getScene().getWindow() : null;
    }

    private Optional<String> askStudentId(String defaultName) {
        TextInputDialog d = new TextInputDialog(defaultName.replace(".java", ""));
        d.setTitle("Student ID");
        d.setHeaderText("Enter a student ID for this submission:");
        d.setContentText("Student ID:");
        return d.showAndWait();
    }

    private File saveDialog(String desc, String ext, String defaultName) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Save Report");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter(desc, ext));
        fc.setInitialFileName(defaultName);
        return fc.showSaveDialog(getStage());
    }

    // Returns a cell factory for boolean columns — shows coloured YES/no text
    private <T> Callback<TableColumn<T, Boolean>, TableCell<T, Boolean>> boolCell(String yes, String no) {
        return col -> new TableCell<>() {
            @Override protected void updateItem(Boolean v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setStyle(""); return; }
                setText(v ? yes : no);
                setStyle(v ? "-fx-text-fill:#f85149;" : "-fx-text-fill:#3fb950;");
            }
        };
    }

    private void addFormRow(GridPane g, String label, Control field, int row) {
        Label l = new Label(label);
        l.setStyle("-fx-text-fill:#8b949e; -fx-font-size:12px;");
        g.add(l, 0, row);
        g.add(field, 1, row);
        GridPane.setHgrow(field, Priority.ALWAYS);
    }

    private TextField styledField(String prompt) {
        TextField tf = new TextField();
        tf.setPromptText(prompt);
        applyFieldStyle(tf);
        return tf;
    }

    private void applyFieldStyle(TextField tf) {
        tf.setStyle("-fx-background-color:#21262d; -fx-text-fill:#c9d1d9; "
            + "-fx-border-color:#30363d; -fx-border-radius:4; -fx-background-radius:4; -fx-padding:6 10;");
    }

    private void showNoData() {
        showInfo("No Data", "No submissions loaded yet. Analyse a file or run a bulk scan first.");
    }

    private void showError(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle(title); a.setContentText(msg); a.showAndWait();
    }

    private void showInfo(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title); a.setContentText(msg); a.showAndWait();
    }
}
