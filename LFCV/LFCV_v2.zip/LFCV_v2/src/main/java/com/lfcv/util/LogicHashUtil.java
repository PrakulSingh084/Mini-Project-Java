package com.lfcv.util;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.comments.Comment;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;

// Creates a structural "fingerprint" of a Java file.
// The trick: we strip everything that students typically change when copying code
// (variable names, comments, string values) and hash what's left.
// If two files have the same structure, they'll produce the same hash.
public final class LogicHashUtil {

    private LogicHashUtil() {}

    public static String compute(CompilationUnit cu) {
        CompilationUnit clone = cu.clone();

        // Step 1: Remove every comment - they're not part of the logic
        clone.getAllComments().forEach(Comment::remove);

        // Step 2: Walk the tree and anonymise everything a student might rename
        final int[] counter = {0};
        clone.accept(new ModifierVisitor<Void>() {

            @Override
            public Visitable visit(VariableDeclarator n, Void arg) {
                // Variable declarations become VAR_0, VAR_1, etc.
                n.setName("VAR_" + counter[0]++);
                return super.visit(n, arg);
            }

            @Override
            public Visitable visit(NameExpr n, Void arg) {
                // Variable usages get collapsed to a generic "var"
                // We keep class names (which start with uppercase) intact
                String name = n.getNameAsString();
                if (!name.isEmpty() && Character.isLowerCase(name.charAt(0)))
                    n.setName("var");
                return super.visit(n, arg);
            }

            @Override
            public Visitable visit(StringLiteralExpr n, Void arg) {
                // String content is irrelevant to structure
                n.setString("STR");
                return super.visit(n, arg);
            }
        }, null);

        // Step 3: Serialise the now-anonymised tree and hash it
        String tokens = clone.toString().replaceAll("\\s+", " ").trim();
        return sha256(tokens);
    }

    // Returns the normalised source text (before hashing) - useful for the diff view
    public static String getNormalisedSource(CompilationUnit cu) {
        CompilationUnit clone = cu.clone();
        clone.getAllComments().forEach(Comment::remove);
        final int[] counter = {0};
        clone.accept(new ModifierVisitor<Void>() {
            @Override public Visitable visit(VariableDeclarator n, Void arg) {
                n.setName("VAR_" + counter[0]++); return super.visit(n, arg);
            }
            @Override public Visitable visit(NameExpr n, Void arg) {
                String name = n.getNameAsString();
                if (!name.isEmpty() && Character.isLowerCase(name.charAt(0))) n.setName("var");
                return super.visit(n, arg);
            }
            @Override public Visitable visit(StringLiteralExpr n, Void arg) {
                n.setString("STR"); return super.visit(n, arg);
            }
        }, null);
        return clone.toString();
    }

    private static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }
}
