package com.lfcv.visualization;

import com.lfcv.model.CfgNode;
import com.lfcv.model.CfgNode.NodeType;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.paint.CycleMethod;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;

import java.util.*;

// This is the heart of the visual experience.
// We take the raw JGraphT graph and draw it as a proper layered diagram
// using a Sugiyama-inspired layout algorithm.
//
// The layout works in three stages:
//   1. Rank assignment  — assign each node to a horizontal layer using BFS
//   2. Ordering         — sort nodes within each layer to minimise crossing edges
//   3. Coordinate assignment — calculate pixel positions with padding
//
// Then we draw nodes as rounded rectangles colour-coded by type,
// edges as smooth Bezier curves with arrowheads,
// and line numbers as small badges on each node.
public class CfgVisualizer {

    public record RenderContext(Set<Integer> highlightedLines, int versionNumber, boolean versionMode) {}

    // How big each node box is
    private static final int NODE_W   = 180;
    private static final int NODE_H   = 44;

    // Spacing between nodes
    private static final int H_GAP    = 55;
    private static final int V_GAP    = 80;
    private static final int MARGIN_X = 40;
    private static final int MARGIN_Y = 40;

    // Corner radius for rounded rectangles
    private static final int RADIUS   = 10;

    // The dark background colour matching the app theme
    private static final Color BG     = Color.web("#0d1117");

    public Canvas render(Graph<CfgNode, DefaultEdge> graph) {
        return render(graph, null);
    }

    public Canvas render(Graph<CfgNode, DefaultEdge> graph, RenderContext context) {
        if (graph == null || graph.vertexSet().isEmpty()) {
            return emptyCanvas("No graph to display");
        }

        // Step 1: assign ranks (layers) via BFS from all ENTRY nodes
        Map<CfgNode, Integer> ranks = assignRanks(graph);

        // Step 2: group nodes by rank and sort within each layer
        Map<Integer, List<CfgNode>> layers = groupByRank(graph, ranks);
        sortWithinLayers(layers, graph);

        // Step 3: compute pixel positions
        Map<CfgNode, double[]> positions = computePositions(layers);

        // Work out how big the canvas needs to be
        double maxX = positions.values().stream().mapToDouble(p -> p[0]).max().orElse(400);
        double maxY = positions.values().stream().mapToDouble(p -> p[1]).max().orElse(400);
        double width  = Math.max(900, maxX + NODE_W + MARGIN_X * 2);
        double height = Math.max(600, maxY + NODE_H + MARGIN_Y * 2);

        Canvas canvas = new Canvas(width, height);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        drawBackground(gc, width, height);
        drawEdges(gc, graph, positions, context);
        drawNodes(gc, positions, context);

        return canvas;
    }

    // ── Layout: Step 1 — Rank Assignment ─────────────────────────────────────

    private Map<CfgNode, Integer> assignRanks(Graph<CfgNode, DefaultEdge> graph) {
        Map<CfgNode, Integer> ranks = new LinkedHashMap<>();
        Queue<CfgNode> queue = new ArrayDeque<>();

        // Start BFS from all ENTRY nodes
        graph.vertexSet().stream()
            .filter(n -> n.getType() == NodeType.ENTRY)
            .forEach(n -> { ranks.put(n, 0); queue.add(n); });

        // If there are no entry nodes (shouldn't happen, but just in case), start from all sources
        if (queue.isEmpty()) {
            graph.vertexSet().stream()
                .filter(n -> graph.inDegreeOf(n) == 0)
                .forEach(n -> { ranks.put(n, 0); queue.add(n); });
        }

        while (!queue.isEmpty()) {
            CfgNode current = queue.poll();
            int rank = ranks.get(current);
            for (DefaultEdge edge : graph.outgoingEdgesOf(current)) {
                CfgNode target = graph.getEdgeTarget(edge);
                // Only update if we found a longer path (handles back-edges in loops)
                if (!ranks.containsKey(target) || ranks.get(target) < rank + 1) {
                    ranks.put(target, rank + 1);
                    queue.add(target);
                }
            }
        }

        // Any unreachable nodes go at the bottom
        int maxRank = ranks.values().stream().mapToInt(i -> i).max().orElse(0);
        graph.vertexSet().stream()
            .filter(n -> !ranks.containsKey(n))
            .forEach(n -> ranks.put(n, maxRank + 1));

        return ranks;
    }

    // ── Layout: Step 2 — Layer Grouping and Ordering ──────────────────────────

    private Map<Integer, List<CfgNode>> groupByRank(Graph<CfgNode, DefaultEdge> graph,
                                                     Map<CfgNode, Integer> ranks) {
        Map<Integer, List<CfgNode>> layers = new TreeMap<>();
        ranks.forEach((node, rank) ->
            layers.computeIfAbsent(rank, k -> new ArrayList<>()).add(node));
        return layers;
    }

    // Simple barycenter ordering: sort nodes by the average position of their predecessors.
    // This dramatically reduces edge crossings compared to arbitrary ordering.
    private void sortWithinLayers(Map<Integer, List<CfgNode>> layers,
                                  Graph<CfgNode, DefaultEdge> graph) {
        Map<CfgNode, Double> positions = new HashMap<>();

        // First layer nodes just get sequential positions
        List<CfgNode> firstLayer = layers.get(layers.keySet().iterator().next());
        if (firstLayer != null) {
            for (int i = 0; i < firstLayer.size(); i++) {
                positions.put(firstLayer.get(i), (double) i);
            }
        }

        // For each subsequent layer, sort by average predecessor position
        for (Map.Entry<Integer, List<CfgNode>> entry : layers.entrySet()) {
            List<CfgNode> layer = entry.getValue();
            layer.sort((a, b) -> {
                double posA = averagePredecessorPosition(a, graph, positions);
                double posB = averagePredecessorPosition(b, graph, positions);
                return Double.compare(posA, posB);
            });
            for (int i = 0; i < layer.size(); i++) {
                positions.put(layer.get(i), (double) i);
            }
        }
    }

    private double averagePredecessorPosition(CfgNode node,
                                               Graph<CfgNode, DefaultEdge> graph,
                                               Map<CfgNode, Double> positions) {
        List<Double> preds = new ArrayList<>();
        for (DefaultEdge edge : graph.incomingEdgesOf(node)) {
            CfgNode source = graph.getEdgeSource(edge);
            if (positions.containsKey(source)) preds.add(positions.get(source));
        }
        return preds.isEmpty() ? 0 : preds.stream().mapToDouble(d -> d).average().orElse(0);
    }

    // ── Layout: Step 3 — Pixel Coordinate Assignment ──────────────────────────

    private Map<CfgNode, double[]> computePositions(Map<Integer, List<CfgNode>> layers) {
        Map<CfgNode, double[]> positions = new HashMap<>();

        int rank = 0;
        for (List<CfgNode> layer : layers.values()) {
            // Centre each layer horizontally
            double totalWidth = layer.size() * NODE_W + (layer.size() - 1) * H_GAP;
            double startX = MARGIN_X;

            for (int i = 0; i < layer.size(); i++) {
                double x = startX + i * (NODE_W + H_GAP);
                double y = MARGIN_Y + rank * (NODE_H + V_GAP);
                positions.put(layer.get(i), new double[]{x, y});
            }
            rank++;
        }

        return positions;
    }

    // ── Drawing ───────────────────────────────────────────────────────────────

    private void drawBackground(GraphicsContext gc, double width, double height) {
        // Deep dark background with a subtle gradient
        LinearGradient bg = new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
            new Stop(0, Color.web("#0d1117")),
            new Stop(1, Color.web("#161b22")));
        gc.setFill(bg);
        gc.fillRect(0, 0, width, height);

        // Subtle grid lines to give depth
        gc.setStroke(Color.web("#21262d", 0.5));
        gc.setLineWidth(0.5);
        for (double x = 0; x < width; x += 40) gc.strokeLine(x, 0, x, height);
        for (double y = 0; y < height; y += 40) gc.strokeLine(0, y, width, y);
    }

    private void drawEdges(GraphicsContext gc, Graph<CfgNode, DefaultEdge> graph,
                           Map<CfgNode, double[]> positions, RenderContext context) {
        for (DefaultEdge edge : graph.edgeSet()) {
            CfgNode src = graph.getEdgeSource(edge);
            CfgNode tgt = graph.getEdgeTarget(edge);
            if (!positions.containsKey(src) || !positions.containsKey(tgt)) continue;

            double[] sp = positions.get(src);
            double[] tp = positions.get(tgt);

            double sx = sp[0] + NODE_W / 2.0;
            double sy = sp[1] + NODE_H;
            double tx = tp[0] + NODE_W / 2.0;
            double ty = tp[1];

            // Back-edges (loops) curve around to the left to avoid overlapping
            boolean isBackEdge = tp[1] <= sp[1];

            if (isBackEdge) {
                drawLoopEdge(gc, sx, sy, tx, ty);
            } else {
                drawForwardEdge(gc, sx, sy, tx, ty, src, tgt, context);
            }
        }
    }

    private void drawForwardEdge(GraphicsContext gc,
                                  double sx, double sy, double tx, double ty,
                                  CfgNode src, CfgNode tgt, RenderContext context) {
        // Pick edge colour based on what the target node is
        Color edgeColor = edgeColor(src, tgt, context);

        gc.setStroke(edgeColor);
        gc.setLineWidth(1.8);

        // Draw a Bezier curve so edges don't overlap the nodes they pass through
        double controlY = (sy + ty) / 2.0;
        gc.beginPath();
        gc.moveTo(sx, sy);
        gc.bezierCurveTo(sx, controlY, tx, controlY, tx, ty);
        gc.stroke();

        drawArrowhead(gc, tx, ty, Math.atan2(ty - controlY, tx - tx), edgeColor);
    }

    private void drawLoopEdge(GraphicsContext gc, double sx, double sy, double tx, double ty) {
        // Loop back-edges curve to the left with a distinctive dashed style
        gc.setStroke(Color.web("#f0a800", 0.9));
        gc.setLineWidth(1.5);
        gc.setLineDashes(6, 4);

        double curveX = Math.min(sx, tx) - 60;
        gc.beginPath();
        gc.moveTo(sx, sy);
        gc.bezierCurveTo(curveX, sy + 20, curveX, ty - 20, tx, ty);
        gc.stroke();

        gc.setLineDashes(null);
        drawArrowhead(gc, tx, ty, Math.atan2(ty - (ty - 20), tx - curveX), Color.web("#f0a800", 0.9));
    }

    private void drawArrowhead(GraphicsContext gc, double tx, double ty, double angle, Color color) {
        double size  = 10;
        double spread = Math.PI / 7;
        double x1 = tx - size * Math.cos(angle - spread);
        double y1 = ty - size * Math.sin(angle - spread);
        double x2 = tx - size * Math.cos(angle + spread);
        double y2 = ty - size * Math.sin(angle + spread);

        gc.setFill(color);
        gc.fillPolygon(new double[]{tx, x1, x2}, new double[]{ty, y1, y2}, 3);
    }

    private void drawNodes(GraphicsContext gc, Map<CfgNode, double[]> positions, RenderContext context) {
        Font labelFont   = Font.font("Consolas", FontWeight.NORMAL, 11);
        Font lineNumFont = Font.font("Consolas", FontWeight.NORMAL, 9);

        positions.forEach((node, pos) -> {
            double x = pos[0];
            double y = pos[1];

            NodeColors colors = nodeColors(node, context);

            // Outer glow effect — draw a slightly larger blurred rectangle behind the node
            gc.setFill(colors.glow.deriveColor(0, 1, 1, 0.25));
            gc.fillRoundRect(x - 4, y - 4, NODE_W + 8, NODE_H + 8, RADIUS + 4, RADIUS + 4);

            // Main node body with a gradient fill
            LinearGradient fill = new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                new Stop(0, colors.top),
                new Stop(1, colors.bottom));
            gc.setFill(fill);
            gc.fillRoundRect(x, y, NODE_W, NODE_H, RADIUS, RADIUS);

            // Border
            gc.setStroke(colors.border);
            gc.setLineWidth(1.5);
            gc.strokeRoundRect(x, y, NODE_W, NODE_H, RADIUS, RADIUS);

            // Node label
            gc.setFill(Color.WHITE);
            gc.setFont(labelFont);
            gc.setTextAlign(TextAlignment.CENTER);
            gc.fillText(node.getLabel(), x + NODE_W / 2.0, y + NODE_H / 2.0 + 4, NODE_W - 16);

            // Line number badge in the top right corner
            if (node.getLineNumber() > 0) {
                gc.setFont(lineNumFont);
                gc.setFill(Color.web("#ffffff", 0.5));
                gc.setTextAlign(TextAlignment.RIGHT);
                gc.fillText("L" + node.getLineNumber(), x + NODE_W - 5, y + 12);
            }

            // Node type icon in the top left corner
            gc.setTextAlign(TextAlignment.LEFT);
            gc.setFill(colors.border().deriveColor(0, 1, 2, 0.8));
            gc.fillText(nodeIcon(node.getType()), x + 6, y + 12);
        });
    }

    // ── Colour scheme ─────────────────────────────────────────────────────────

    private record NodeColors(Color top, Color bottom, Color border, Color glow) {}

    private NodeColors nodeColors(CfgNode node, RenderContext context) {
        if (context != null && context.versionMode()) {
            boolean highlighted = node.getLineNumber() <= 0 || context.highlightedLines().contains(node.getLineNumber());
            return highlighted ? versionAccent(context.versionNumber()) : neutralNodeColors();
        }
        return defaultNodeColors(node.getType());
    }

    private NodeColors defaultNodeColors(NodeType type) {
        return switch (type) {
            case ENTRY         -> new NodeColors(Color.web("#1a6b3c"), Color.web("#0f4a2a"), Color.web("#3fb950"), Color.web("#3fb950"));
            case EXIT          -> new NodeColors(Color.web("#6b1a1a"), Color.web("#4a0f0f"), Color.web("#f85149"), Color.web("#f85149"));
            case IF_CONDITION  -> new NodeColors(Color.web("#6b4a0f"), Color.web("#4a3209"), Color.web("#e3b341"), Color.web("#e3b341"));
            case WHILE_CONDITION, FOR_INIT -> new NodeColors(Color.web("#4a4a0f"), Color.web("#323209"), Color.web("#d2a800"), Color.web("#d2a800"));
            case SWITCH_HEADER, CASE_BLOCK -> new NodeColors(Color.web("#6b2a0f"), Color.web("#4a1e09"), Color.web("#f0623a"), Color.web("#f0623a"));
            case RETURN        -> new NodeColors(Color.web("#1a3a6b"), Color.web("#0f2a4a"), Color.web("#58a6ff"), Color.web("#58a6ff"));
            case THROW         -> new NodeColors(Color.web("#6b1a3a"), Color.web("#4a0f2a"), Color.web("#f778a1"), Color.web("#f778a1"));
            case TRY_BLOCK     -> new NodeColors(Color.web("#2a1a6b"), Color.web("#1e0f4a"), Color.web("#a371f7"), Color.web("#a371f7"));
            case CATCH_BLOCK   -> new NodeColors(Color.web("#4a1a6b"), Color.web("#321440"), Color.web("#bc8cff"), Color.web("#bc8cff"));
            case FINALLY_BLOCK -> new NodeColors(Color.web("#1a4a6b"), Color.web("#0f3248"), Color.web("#79c0ff"), Color.web("#79c0ff"));
            case METHOD_CALL   -> new NodeColors(Color.web("#1a6b6b"), Color.web("#0f4848"), Color.web("#56d364"), Color.web("#56d364"));
            default            -> new NodeColors(Color.web("#21262d"), Color.web("#161b22"), Color.web("#388bfd"), Color.web("#388bfd"));
        };
    }

    private NodeColors neutralNodeColors() {
        return new NodeColors(Color.web("#252b35"), Color.web("#1a1f28"), Color.web("#6e7681"), Color.web("#6e7681"));
    }

    private NodeColors versionAccent(int versionNumber) {
        return switch (Math.floorMod(versionNumber - 1, 5)) {
            case 0 -> new NodeColors(Color.web("#1c4f7a"), Color.web("#163a58"), Color.web("#58a6ff"), Color.web("#58a6ff"));
            case 1 -> new NodeColors(Color.web("#1e5a43"), Color.web("#164232"), Color.web("#3fb950"), Color.web("#3fb950"));
            case 2 -> new NodeColors(Color.web("#6b4b1f"), Color.web("#4f3817"), Color.web("#e3b341"), Color.web("#e3b341"));
            case 3 -> new NodeColors(Color.web("#5b274f"), Color.web("#431d3a"), Color.web("#d2a8ff"), Color.web("#d2a8ff"));
            default -> new NodeColors(Color.web("#6a2f25"), Color.web("#4a211b"), Color.web("#ff7b72"), Color.web("#ff7b72"));
        };
    }

    private Color edgeColor(CfgNode source, CfgNode target, RenderContext context) {
        if (context != null && context.versionMode()) {
            boolean highlighted = source.getLineNumber() <= 0
                || target.getLineNumber() <= 0
                || context.highlightedLines().contains(source.getLineNumber())
                || context.highlightedLines().contains(target.getLineNumber());
            return highlighted
                ? versionAccent(context.versionNumber()).border().deriveColor(0, 1, 1, 0.75)
                : Color.web("#6e7681", 0.55);
        }
        return switch (target.getType()) {
            case EXIT          -> Color.web("#f85149", 0.8);
            case IF_CONDITION  -> Color.web("#e3b341", 0.8);
            case RETURN, THROW -> Color.web("#58a6ff", 0.8);
            case CATCH_BLOCK   -> Color.web("#bc8cff", 0.8);
            default            -> Color.web("#388bfd", 0.7);
        };
    }

    private String nodeIcon(NodeType type) {
        return switch (type) {
            case ENTRY         -> "▶";
            case EXIT          -> "■";
            case IF_CONDITION  -> "◆";
            case WHILE_CONDITION, FOR_INIT -> "↺";
            case SWITCH_HEADER -> "⊞";
            case CASE_BLOCK    -> "▷";
            case RETURN        -> "←";
            case THROW         -> "!";
            case TRY_BLOCK     -> "T";
            case CATCH_BLOCK   -> "C";
            case FINALLY_BLOCK -> "F";
            case METHOD_CALL   -> "→";
            default            -> "·";
        };
    }

    private Canvas emptyCanvas(String message) {
        Canvas c = new Canvas(600, 200);
        GraphicsContext gc = c.getGraphicsContext2D();
        gc.setFill(BG);
        gc.fillRect(0, 0, 600, 200);
        gc.setFill(Color.web("#8b949e"));
        gc.setFont(Font.font("Consolas", 14));
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText(message, 300, 100);
        return c;
    }
}
