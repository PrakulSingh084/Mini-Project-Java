package com.lfcv;

import com.lfcv.comparison.FileComparisonService;
import com.lfcv.comparison.LineChangeType;
import com.lfcv.comparison.VersionDiffResult;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FileComparisonServiceTest {

    private final FileComparisonService comparisonService = new FileComparisonService();

    @Test
    void marksBaselineUploadAsAdded() {
        VersionDiffResult result = comparisonService.compare(null, "class Demo {\n}", 0, 1);

        assertEquals(2, result.addedCount());
        assertEquals(0, result.modifiedCount());
        assertEquals(0, result.unchangedCount());
        assertTrue(result.highlightedLineNumbers().contains(1));
        assertTrue(result.highlightedLineNumbers().contains(2));
    }

    @Test
    void marksChangedAndAddedLinesForReupload() {
        String previous = """
            class Demo {
                int sum(int a, int b) {
                    return a + b;
                }
            }
            """;
        String current = """
            class Demo {
                int sum(int a, int b) {
                    int total = a + b;
                    return total;
                }
            }
            """;

        VersionDiffResult result = comparisonService.compare(previous, current, 1, 2);

        assertEquals(5, result.unchangedCount());
        assertEquals(1, result.modifiedCount());
        assertEquals(1, result.addedCount());
        assertTrue(result.lines().stream().anyMatch(line -> line.changeType() == LineChangeType.MODIFIED));
        assertTrue(result.lines().stream().anyMatch(line -> line.changeType() == LineChangeType.ADDED));
    }
}
