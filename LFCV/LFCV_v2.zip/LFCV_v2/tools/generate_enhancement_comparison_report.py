from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ACCENT = RGBColor(56, 139, 253)
BG_DARK = "0D1117"
BG_PANEL = "161B22"
BORDER = "30363D"
TEXT_LIGHT = RGBColor(201, 209, 217)
TEXT_MUTED = RGBColor(139, 148, 158)
TEXT_SUCCESS = RGBColor(63, 185, 80)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_margins(cell, top=70, start=110, bottom=70, end=110):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for key, value in {"top": top, "start": start, "bottom": bottom, "end": end}.items():
        node = tc_mar.find(qn(f"w:{key}"))
        if node is None:
            node = OxmlElement(f"w:{key}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_run_font(run, size, bold=False, color=TEXT_LIGHT, name="Aptos"):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color


def set_page_margins(section):
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)


def add_header(section):
    header = section.header
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = p.add_run("Logic-Flow Code Visualizer  •  Enhancement Comparison")
    set_run_font(run, 9, color=TEXT_MUTED)


def add_footer(section):
    footer = section.footer
    table = footer.add_table(rows=1, cols=2, width=Inches(6.5))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    left = table.cell(0, 0)
    right = table.cell(0, 1)
    left.text = "Session: 2025-2026"
    right.text = "Dr. Vishwanath Karad MIT World Peace University"
    for cell, align in ((left, WD_ALIGN_PARAGRAPH.LEFT), (right, WD_ALIGN_PARAGRAPH.RIGHT)):
        para = cell.paragraphs[0]
        para.alignment = align
        run = para.runs[0]
        set_run_font(run, 8, color=TEXT_MUTED)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def style_normal(doc):
    style = doc.styles["Normal"]
    style.font.name = "Aptos"
    style._element.rPr.rFonts.set(qn("w:ascii"), "Aptos")
    style._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos")
    style.font.size = Pt(10.5)


def add_cover(doc):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.space_after = Pt(10)
    run = p.add_run("Logic-Flow Code Visualizer (LFCV)")
    set_run_font(run, 22, bold=True, color=ACCENT, name="Aptos Display")

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("Comparative Report: Earlier Version vs Updated Version")
    set_run_font(run, 15, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.space_after = Pt(20)
    run = p.add_run("Prepared for Mini Project Documentation")
    set_run_font(run, 11, color=TEXT_MUTED)

    panel = doc.add_table(rows=5, cols=2)
    panel.alignment = WD_TABLE_ALIGNMENT.CENTER
    panel.autofit = False
    panel.columns[0].width = Inches(2.2)
    panel.columns[1].width = Inches(4.3)
    labels = [
        ("Programme", "T.Y. B.Tech CSE (Artificial Intelligence & Data Science)"),
        ("Session", "2025-2026"),
        ("Institution", "Dr. Vishwanath Karad MIT World Peace University"),
        ("Document Purpose", "To record the implemented enhancements made to the original LFCV desktop application"),
        ("Screenshots", "To be inserted by the project team in the dedicated placeholders provided later in this report"),
    ]
    for idx, (left_text, right_text) in enumerate(labels):
        left = panel.cell(idx, 0)
        right = panel.cell(idx, 1)
        left.text = left_text
        right.text = right_text
        for cell in (left, right):
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_shading(cell, BG_PANEL if cell is left else BG_DARK)
            para = cell.paragraphs[0]
            para.alignment = WD_ALIGN_PARAGRAPH.LEFT
            para.paragraph_format.space_after = Pt(0)
            for run in para.runs:
                set_run_font(run, 10.5, bold=(cell is left))

    doc.add_paragraph()
    team_heading = doc.add_paragraph()
    team_heading.paragraph_format.space_before = Pt(8)
    team_heading_run = team_heading.add_run("Group Members")
    set_run_font(team_heading_run, 13, bold=True, color=ACCENT)

    team = doc.add_table(rows=1, cols=3)
    team.alignment = WD_TABLE_ALIGNMENT.CENTER
    headers = ["Name", "PRN", "Roll No."]
    for i, text in enumerate(headers):
        cell = team.rows[0].cells[i]
        cell.text = text
        set_cell_shading(cell, BG_PANEL)
        set_cell_margins(cell)
        para = cell.paragraphs[0]
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_run_font(para.runs[0], 10.5, bold=True)

    for row_values in [
        ("Prakul Singh", "1032233410", "44"),
        ("Vedika Rana", "103223359", "49"),
    ]:
        row = team.add_row().cells
        for idx, value in enumerate(row_values):
            row[idx].text = value
            set_cell_shading(row[idx], BG_DARK)
            set_cell_margins(row[idx])
            row[idx].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            para = row[idx].paragraphs[0]
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            set_run_font(para.runs[0], 10.5)

    doc.add_page_break()


def add_heading(doc, text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run(text)
    set_run_font(run, 14 if level == 1 else 11.5, bold=True, color=ACCENT if level == 1 else TEXT_LIGHT)
    return p


def add_body_paragraph(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(5)
    run = p.add_run(text)
    set_run_font(run, 10.5)
    return p


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    run = p.add_run(text)
    set_run_font(run, 10.3)
    return p


def add_comparison_table(doc):
    add_heading(doc, "1. Comparative Summary")
    add_body_paragraph(
        doc,
        "The original LFCV version already supported static Java analysis, bulk scanning, integrity checking, "
        "and Control Flow Graph rendering. The updated version retains the same dashboard style while adding "
        "version-aware comparison and graph-difference visualization."
    )

    table = doc.add_table(rows=1, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    widths = [1.6, 2.2, 2.2, 1.5]
    for col, width in zip(table.columns, widths):
        col.width = Inches(width)

    headers = ["Feature Area", "Earlier Version", "Updated Version", "Impact"]
    for i, text in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = text
        set_cell_shading(cell, BG_PANEL)
        set_cell_margins(cell, top=90, bottom=90)
        para = cell.paragraphs[0]
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_run_font(para.runs[0], 10.2, bold=True)

    rows = [
        (
            "Java File Handling",
            "Each file was analysed as an isolated upload.",
            "Re-upload of the same submission can be tracked as a new version with stored history metadata.",
            "Supports iterative review."
        ),
        (
            "Line-by-Line Comparison",
            "No built-in source comparison between versions.",
            "Dedicated Version Compare view shows unchanged, modified, added, and removed lines.",
            "Improves code review clarity."
        ),
        (
            "CFG Selection",
            "CFG rendering depended mainly on table row selection.",
            "Dedicated CFG submission selector and Show CFG action were added for reliable switching.",
            "More foolproof workflow."
        ),
        (
            "CFG Colour Logic",
            "Single node-type based colour logic only.",
            "Version-aware highlight mode accents added or modified nodes and mutes unchanged nodes.",
            "Makes change hotspots visible."
        ),
        (
            "Version Identity",
            "No visible version label in analysis detail.",
            "Version label, previous version reference, and change counts are displayed in the detail panel.",
            "Adds traceability."
        ),
        (
            "Demonstration Support",
            "No guided version comparison samples.",
            "Ready-to-use sample Java files were added for validating v1 and v2 comparison behaviour.",
            "Faster academic demo preparation."
        ),
    ]

    for values in rows:
        cells = table.add_row().cells
        for idx, value in enumerate(values):
            cells[idx].text = value
            set_cell_shading(cells[idx], BG_DARK)
            set_cell_margins(cells[idx], top=80, bottom=80)
            cells[idx].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            para = cells[idx].paragraphs[0]
            para.alignment = WD_ALIGN_PARAGRAPH.LEFT if idx < 3 else WD_ALIGN_PARAGRAPH.CENTER
            set_run_font(para.runs[0], 9.9)


def add_detailed_changes(doc):
    add_heading(doc, "2. Detailed Enhancements")

    add_heading(doc, "2.1 Version-Aware Comparative Analysis", level=2)
    add_bullet(doc, "A new comparison service stores submission history and computes differences across versions of the same Java submission.")
    add_bullet(doc, "The updated system marks code lines as unchanged, modified, added, or removed.")
    add_bullet(doc, "The Version Compare tab provides an interface similar to conversational code review, making the change list easier to interpret.")
    add_bullet(doc, "Version history labels are retained so faculty can understand how a submission evolved across uploads.")

    add_heading(doc, "2.2 Control Flow Graph Enhancements", level=2)
    add_bullet(doc, "The CFG tab now includes a dedicated dropdown and action button so a specific submission can be visualised on demand.")
    add_bullet(doc, "The baseline graph remains visually consistent with the existing LFCV theme.")
    add_bullet(doc, "For later versions, only added or modified nodes are accent-coloured, while unchanged nodes are muted.")
    add_bullet(doc, "The active version palette is displayed in the CFG header, making it easier to verify that version-specific highlighting is applied.")

    add_heading(doc, "2.3 User Experience Continuity", level=2)
    add_bullet(doc, "The original dashboard structure, dark palette, and reporting-oriented academic look were preserved.")
    add_bullet(doc, "The enhancements were integrated into the same application rather than presented as a visually separate tool.")
    add_bullet(doc, "This ensures the updated version still appears as an enhancement to LFCV rather than a completely rebuilt program.")


def add_implementation_notes(doc):
    add_heading(doc, "3. Implementation Notes")
    add_body_paragraph(
        doc,
        "The updated version focuses on the first two requested enhancement areas: comparative analysis of repeated Java uploads and "
        "Control Flow Graph highlighting of changes across versions. The report therefore concentrates on these completed and stabilised changes."
    )
    add_body_paragraph(
        doc,
        "During the update, sample Java files were also added to help validate the comparison workflow. This reduces ambiguity during project demonstration "
        "and helps verify that the CFG for different versions can be selected and rendered correctly."
    )


def add_screenshot_placeholders(doc):
    add_heading(doc, "4. Screenshot Placeholders")
    add_body_paragraph(
        doc,
        "The following placeholders are intentionally left for manual insertion of screenshots by the project team."
    )
    placeholders = [
        "Screenshot 1: Earlier version dashboard or original submission analysis view",
        "Screenshot 2: Updated Version Compare tab showing line-by-line source differences",
        "Screenshot 3: CFG of baseline version (v1) before changes",
        "Screenshot 4: CFG of updated version (v2) with highlighted modified or added nodes",
    ]
    for text in placeholders:
        outer = doc.add_table(rows=1, cols=1)
        outer.alignment = WD_TABLE_ALIGNMENT.CENTER
        outer.autofit = False
        outer.columns[0].width = Inches(6.3)
        cell = outer.cell(0, 0)
        cell.text = "\n" + text + "\n\n[Insert screenshot here]\n"
        set_cell_shading(cell, BG_DARK)
        set_cell_margins(cell, top=220, bottom=220, start=160, end=160)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        para = cell.paragraphs[0]
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for idx, run in enumerate(para.runs):
            set_run_font(run, 10.4, bold=(idx == 0), color=TEXT_MUTED if idx > 0 else TEXT_LIGHT)
        doc.add_paragraph()


def add_conclusion(doc):
    add_heading(doc, "5. Conclusion")
    add_body_paragraph(
        doc,
        "The updated LFCV version extends the earlier academic static analysis tool with practical version comparison and graph-difference visibility. "
        "These changes make the system more suitable for iterative code review, project viva demonstrations, and evaluation of evolving Java submissions."
    )
    add_body_paragraph(
        doc,
        "Because the enhancements were applied within the same interface theme and dashboard structure, the final result continues to reflect the original "
        "LFCV identity while offering stronger analytical capability."
    )


def main():
    doc = Document()
    style_normal(doc)
    section = doc.sections[0]
    set_page_margins(section)
    add_header(section)
    add_footer(section)
    add_cover(doc)

    for section in doc.sections:
        set_page_margins(section)
        add_header(section)
        add_footer(section)

    add_comparison_table(doc)
    add_detailed_changes(doc)
    add_implementation_notes(doc)
    add_screenshot_placeholders(doc)
    add_conclusion(doc)

    output_path = "/Users/prakul_singh_88/Documents/New project 2/LFCV_v2/LFCV_Enhancement_Comparison_Report.docx"
    doc.save(output_path)
    print(output_path)


if __name__ == "__main__":
    main()
